
<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto p-8 bg-white rounded shadow">
    <h1 class="text-2xl font-bold mb-6">Create Plant</h1>
    <form action="<?php echo e(route('plants.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="name" class="block font-semibold mb-2">Name</label>
            <input type="text" name="name" id="name" class="w-full border rounded px-3 py-2" required>
        </div>
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded">Create</button>
        <a href="<?php echo e(route('plants.index')); ?>" class="ml-4 text-gray-600 hover:underline">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proj\tpmerpSebelumTambahRole\resources\views/plants/create.blade.php ENDPATH**/ ?>