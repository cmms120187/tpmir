
<?php $__env->startSection('content'); ?>
<div class="w-full p-4 sm:p-6 lg:p-8">
    <div class="w-full mx-auto max-w-6xl">
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Update Predictive Maintenance Execution</h1>
            <a href="<?php echo e(route('predictive-maintenance.controlling.index')); ?>" class="text-gray-600 hover:text-gray-800">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </a>
        </div>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('predictive-maintenance.controlling.update', $execution->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Execution Information</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Machine Info -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Machine</label>
                        <div class="border rounded px-3 py-2 bg-gray-50">
                            <div class="font-semibold text-gray-900"><?php echo e($execution->schedule->machineErp->idMachine ?? '-'); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($execution->schedule->machineErp->machineType->name ?? '-'); ?></div>
                            <div class="text-xs text-gray-400">
                                <?php echo e($execution->schedule->machineErp->plant_name ?? '-'); ?> /
                                <?php echo e($execution->schedule->machineErp->line_name ?? '-'); ?>

                            </div>
                        </div>
                    </div>

                    <!-- Scheduled Date -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Scheduled Date</label>
                        <div class="border rounded px-3 py-2 bg-gray-50">
                            <?php echo e($execution->scheduled_date ? \Carbon\Carbon::parse($execution->scheduled_date)->format('d/m/Y') : '-'); ?>

                        </div>
                    </div>

                    <!-- Standard Info -->
                    <?php if($execution->schedule->standard): ?>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Standard</label>
                        <div class="border rounded px-3 py-2 bg-blue-50">
                            <div class="font-semibold text-blue-900"><?php echo e($execution->schedule->standard->name ?? '-'); ?></div>
                            <div class="text-sm text-blue-700">
                                Range: <?php echo e($execution->schedule->standard->min_value ?? '-'); ?> - <?php echo e($execution->schedule->standard->max_value ?? '-'); ?> <?php echo e($execution->schedule->standard->unit ?? ''); ?>

                                <?php if($execution->schedule->standard->target_value !== null): ?>
                                    | Target: <?php echo e($execution->schedule->standard->target_value); ?> <?php echo e($execution->schedule->standard->unit ?? ''); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Status -->
                    <div>
                        <label for="status" class="block text-sm font-medium text-gray-700 mb-2">Status <span class="text-red-500">*</span></label>
                        <select name="status" id="status" class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="pending" <?php echo e(old('status', $execution->status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="in_progress" <?php echo e(old('status', $execution->status) == 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                            <option value="completed" <?php echo e(old('status', $execution->status) == 'completed' ? 'selected' : ''); ?>>Completed</option>
                            <option value="skipped" <?php echo e(old('status', $execution->status) == 'skipped' ? 'selected' : ''); ?>>Skipped</option>
                            <option value="cancelled" <?php echo e(old('status', $execution->status) == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Measured Value -->
                    <div>
                        <label for="measured_value" class="block text-sm font-medium text-gray-700 mb-2">
                            Measured Value
                            <?php if($execution->schedule->standard): ?>
                                <span class="text-gray-500 text-xs">(<?php echo e($execution->schedule->standard->unit ?? ''); ?>)</span>
                            <?php endif; ?>
                        </label>
                        <input type="number"
                               name="measured_value"
                               id="measured_value"
                               step="0.01"
                               value="<?php echo e(old('measured_value', $execution->measured_value ?? '')); ?>"
                               class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['measured_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Masukkan nilai pengukuran">
                        <?php if($execution->schedule->standard): ?>
                            <p class="text-xs text-gray-500 mt-1">
                                Range: <?php echo e($execution->schedule->standard->min_value ?? '-'); ?> - <?php echo e($execution->schedule->standard->max_value ?? '-'); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($execution->measurement_status): ?>
                            <p class="text-xs mt-1">
                                <span class="px-2 py-0.5 rounded
                                    <?php if($execution->measurement_status == 'normal'): ?> bg-green-100 text-green-800
                                    <?php elseif($execution->measurement_status == 'warning'): ?> bg-yellow-100 text-yellow-800
                                    <?php else: ?> bg-red-100 text-red-800
                                    <?php endif; ?>">
                                    Status: <?php echo e(ucfirst($execution->measurement_status)); ?>

                                </span>
                            </p>
                        <?php endif; ?>
                        <?php $__errorArgs = ['measured_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Performed By -->
                    <div>
                        <label for="performed_by" class="block text-sm font-medium text-gray-700 mb-2">Performed By</label>
                        <select name="performed_by" id="performed_by" class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['performed_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('performed_by', $execution->performed_by) == $user->id ? 'selected' : ''); ?>>
                                    <?php if($user->nik): ?><?php echo e($user->nik); ?> - <?php endif; ?><?php echo e($user->name); ?> (<?php echo e(ucfirst(str_replace('_', ' ', $user->role))); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['performed_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Actual Start Time -->
                    <div>
                        <label for="actual_start_time" class="block text-sm font-medium text-gray-700 mb-2">Actual Start Time</label>
                        <input type="datetime-local"
                               name="actual_start_time"
                               id="actual_start_time"
                               value="<?php echo e(old('actual_start_time', $execution->actual_start_time ? \Carbon\Carbon::parse($execution->actual_start_time)->format('Y-m-d\TH:i') : '')); ?>"
                               class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['actual_start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['actual_start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Actual End Time -->
                    <div>
                        <label for="actual_end_time" class="block text-sm font-medium text-gray-700 mb-2">Actual End Time</label>
                        <input type="datetime-local"
                               name="actual_end_time"
                               id="actual_end_time"
                               value="<?php echo e(old('actual_end_time', $execution->actual_end_time ? \Carbon\Carbon::parse($execution->actual_end_time)->format('Y-m-d\TH:i') : '')); ?>"
                               class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['actual_end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['actual_end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Cost -->
                    <div>
                        <label for="cost" class="block text-sm font-medium text-gray-700 mb-2">Cost</label>
                        <input type="number"
                               name="cost"
                               id="cost"
                               step="0.01"
                               min="0"
                               value="<?php echo e(old('cost', $execution->cost ?? '')); ?>"
                               class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Findings and Actions -->
            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Findings & Actions</h2>
                <div class="grid grid-cols-1 gap-4">
                    <!-- Findings -->
                    <div>
                        <label for="findings" class="block text-sm font-medium text-gray-700 mb-2">Findings</label>
                        <textarea name="findings"
                                  id="findings"
                                  rows="4"
                                  class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['findings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('findings', $execution->findings ?? '')); ?></textarea>
                        <?php $__errorArgs = ['findings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Actions Taken -->
                    <div>
                        <label for="actions_taken" class="block text-sm font-medium text-gray-700 mb-2">Actions Taken</label>
                        <textarea name="actions_taken"
                                  id="actions_taken"
                                  rows="4"
                                  class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['actions_taken'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('actions_taken', $execution->actions_taken ?? '')); ?></textarea>
                        <?php $__errorArgs = ['actions_taken'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Notes -->
                    <div>
                        <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                        <textarea name="notes"
                                  id="notes"
                                  rows="3"
                                  class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('notes', $execution->notes ?? '')); ?></textarea>
                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Photos Section -->
            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">Photos</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Photo Before -->
                    <div>
                        <label for="photo_before" class="block text-sm font-medium text-gray-700 mb-2">Photo Before</label>
                        <?php if($execution->photo_before): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('storage/' . $execution->photo_before)); ?>" alt="Photo Before" class="w-full h-48 object-cover rounded border">
                            </div>
                        <?php endif; ?>
                        <input type="file"
                               name="photo_before"
                               id="photo_before"
                               accept="image/*"
                               class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['photo_before'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['photo_before'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Photo After -->
                    <div>
                        <label for="photo_after" class="block text-sm font-medium text-gray-700 mb-2">Photo After</label>
                        <?php if($execution->photo_after): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('storage/' . $execution->photo_after)); ?>" alt="Photo After" class="w-full h-48 object-cover rounded border">
                            </div>
                        <?php endif; ?>
                        <input type="file"
                               name="photo_after"
                               id="photo_after"
                               accept="image/*"
                               class="w-full border rounded px-3 py-2 <?php $__errorArgs = ['photo_after'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['photo_after'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Submit Buttons -->
            <div class="flex justify-end gap-3">
                <a href="<?php echo e(route('predictive-maintenance.controlling.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white font-semibold py-2 px-6 rounded shadow transition">
                    Cancel
                </a>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded shadow transition">
                    Update Execution
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Auto set start/end time based on status change
document.getElementById('status').addEventListener('change', function() {
    const status = this.value;
    const startTimeInput = document.getElementById('actual_start_time');
    const endTimeInput = document.getElementById('actual_end_time');

    if (status === 'in_progress' && !startTimeInput.value) {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        startTimeInput.value = `${year}-${month}-${day}T${hours}:${minutes}`;
    }

    if (status === 'completed' && !endTimeInput.value) {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        endTimeInput.value = `${year}-${month}-${day}T${hours}:${minutes}`;
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\proj\tpmerpSebelumTambahRole\resources\views/predictive-maintenance/controlling/edit.blade.php ENDPATH**/ ?>