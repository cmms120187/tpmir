<?php

namespace Database\Seeders;

use App\Models\Brand;
use Illuminate\Database\Seeder;

class BrandSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Utility Machine Brands
        $utilityBrands = [
            'Atlas Copco',      // Air Compressor
            'Ingersoll Rand',   // Air Compressor
            'Gardner Denver',   // Blower Exhaust
            'Kaeser',           // Blower Exhaust
            'Bosch',            // Boiler
            'Cleaver-Brooks',   // Boiler
            'Cummins',          // Generator Set
            'Perkins',          // Generator Set
        ];

        // Production Machine Brands
        $productionBrands = [
            'Hobart',           // Mixing Machine
            'Krones',           // Filling Machine, Capping Machine
            'Bosch',            // Packaging Machine
            'Interroll',        // Conveyor Belt
            'Weber',            // Labeling Machine
        ];

        // Quality Control Brands
        $qualityControlBrands = [
            'Mettler Toledo',   // Weighing Scale
            'Hanna Instruments', // pH Meter
            'Shimadzu',         // Spectrophotometer
        ];

        // Combine all brands and remove duplicates
        $allBrands = array_unique(array_merge($utilityBrands, $productionBrands, $qualityControlBrands));

        foreach ($allBrands as $brandName) {
            Brand::firstOrCreate(['name' => $brandName]);
            $this->command->info("Created/Updated Brand: {$brandName}");
        }

        $this->command->info("\nBrand seeding completed!");
        $this->command->info("Total brands created: " . count($allBrands));
    }
}

