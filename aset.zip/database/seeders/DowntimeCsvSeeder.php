<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class DowntimeCsvSeeder extends Seeder
{
    public function run(): void
    {
        $path = base_path('downtime2024revisi.csv');
        if (!file_exists($path)) {
            echo "CSV file not found: $path\n";
            return;
        }
        $csv = array_map('str_getcsv', file($path));
        $header = array_map('trim', explode("\t", $csv[0][0]));
        unset($csv[0]);
        foreach ($csv as $row) {
            $row = explode("\t", $row[0]);
            $data = array_combine($header, $row);

            // Insert or get plant
            $plant = DB::table('plants')->where('name', $data['plant'])->first();
            if (!$plant) {
                $plant_id = DB::table('plants')->insertGetId(['name' => $data['plant'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $plant_id = $plant->id;
            }

            // Insert or get process
            $process = DB::table('processes')->where('name', $data['process'])->first();
            if (!$process) {
                $process_id = DB::table('processes')->insertGetId(['name' => $data['process'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $process_id = $process->id;
            }

            // Insert or get line
            $line = DB::table('lines')->where('name', $data['line'])->first();
            if (!$line) {
                $line_id = DB::table('lines')->insertGetId(['name' => $data['line'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $line_id = $line->id;
            }

            // Insert or get room
            $room = DB::table('rooms')->where('name', $data['roomName'])->first();
            if (!$room) {
                $room_id = DB::table('rooms')->insertGetId(['name' => $data['roomName'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $room_id = $room->id;
            }

            // Insert or get machine type
            $type = DB::table('machine_types')->where('name', $data['typeMachine'])->first();
            if (!$type) {
                $type_id = DB::table('machine_types')->insertGetId(['name' => $data['typeMachine'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $type_id = $type->id;
            }

            // Insert or get brand
            $brand = DB::table('brands')->where('name', $data['brandMachine'])->first();
            if (!$brand) {
                $brand_id = DB::table('brands')->insertGetId(['name' => $data['brandMachine'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $brand_id = $brand->id;
            }

            // Insert or get model
            $model = DB::table('models')->where('name', $data['modelMachine'])->first();
            if (!$model) {
                $model_id = DB::table('models')->insertGetId(['name' => $data['modelMachine'], 'created_at' => now(), 'updated_at' => now()]);
            } else {
                $model_id = $model->id;
            }

            // Insert or get mekanik user
            $mekanik = DB::table('users')->where('idMekanik', $data['idMekanik'])->first();
            if (!$mekanik) {
                $mekanik_id = DB::table('users')->insertGetId([
                    'name' => $data['nameMekanik'],
                    'idMekanik' => $data['idMekanik'],
                    'role' => 'mekanik',
                    'email' => $data['idMekanik'].'@example.com',
                    'password' => bcrypt('password'),
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            } else {
                $mekanik_id = $mekanik->id;
            }

            // Insert or get leader user
            $leader = DB::table('users')->where('idLeader', $data['idLeader'])->first();
            if (!$leader) {
                $leader_id = DB::table('users')->insertGetId([
                    'name' => $data['nameLeader'],
                    'idLeader' => $data['idLeader'],
                    'role' => 'leader',
                    'email' => $data['idLeader'].'@example.com',
                    'password' => bcrypt('password'),
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            } else {
                $leader_id = $leader->id;
            }

            // Insert or get coord user
            $coord = DB::table('users')->where('idCoord', $data['idCoord'])->first();
            if (!$coord) {
                $coord_id = DB::table('users')->insertGetId([
                    'name' => $data['nameCoord'],
                    'idCoord' => $data['idCoord'],
                    'role' => 'coordinator',
                    'email' => $data['idCoord'].'@example.com',
                    'password' => bcrypt('password'),
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            } else {
                $coord_id = $coord->id;
            }

            // Insert or get machine
            $machine = DB::table('machines')->where('idMachine', $data['idMachine'])->first();
            if (!$machine) {
                $machine_id = DB::table('machines')->insertGetId([
                    'plant_id' => $plant_id,
                    'process_id' => $process_id,
                    'line_id' => $line_id,
                    'room_id' => $room_id,
                    'type_id' => $type_id,
                    'brand_id' => $brand_id,
                    'model_id' => $model_id,
                    'idMachine' => $data['idMachine'],
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            } else {
                $machine_id = $machine->id;
            }

            // Insert downtime
            DB::table('downtimes')->insert([
                'machine_id' => $machine_id,
                'date' => $data['date'],
                'stopProduction' => $data['stopProduction'],
                'responMechanic' => $data['responMechanic'],
                'startProduction' => $data['startProduction'],
                'duration' => $data['duration'],
                'standard_time' => $data['Standar Time'],
                'mekanik_id' => $mekanik_id,
                'leader_id' => $leader_id,
                'coord_id' => $coord_id,
                'created_at' => now(),
                'updated_at' => now()
            ]);
        }
    }
}
