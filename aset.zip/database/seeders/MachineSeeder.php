<?php

namespace Database\Seeders;

use App\Models\Machine;
use App\Models\MachineType;
use App\Models\Room;
use App\Models\Brand;
use App\Models\Model;
use Illuminate\Database\Seeder;

class MachineSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get Brands and Models
        $atlasCopco = Brand::where('name', 'Atlas Copco')->first();
        $gardnerDenver = Brand::where('name', 'Gardner Denver')->first();
        $bosch = Brand::where('name', 'Bosch')->first();
        $cummins = Brand::where('name', 'Cummins')->first();

        $ac200Model = Model::where('name', 'AC-200')->first();
        $be500Model = Model::where('name', 'BE-500')->first();
        $bl1000Model = Model::where('name', 'BL-1000')->first();
        $genset500Model = Model::where('name', 'GENSET-500KVA')->first();

        // Get Utility Rooms for each Plant
        $utilityRoomA = Room::where('name', 'Utility Room Plant A')->first();
        $utilityRoomB = Room::where('name', 'Utility Room Plant B')->first();
        $utilityRoomC = Room::where('name', 'Utility Room Plant C')->first();
        $utilityRoomD = Room::where('name', 'Utility Room Plant D')->first();

        // Get Machine Types for Utility Equipment (only one per name now)
        $compressor = MachineType::where('name', 'Air Compressor')->first();
        $blower = MachineType::where('name', 'Blower Exhaust')->first();
        $boiler = MachineType::where('name', 'Boiler')->first();
        $genset = MachineType::where('name', 'Generator Set')->first();

        // Helper function to create machines in a utility room
        $createMachinesInRoom = function($room, $roomName, $plantLetter) use ($compressor, $blower, $boiler, $genset, $atlasCopco, $gardnerDenver, $bosch, $cummins, $ac200Model, $be500Model, $bl1000Model, $genset500Model) {
            if (!$room) return;

            $year = 2023;
            $counter = 1;

            // Air Compressors (2 units)
            if ($compressor && $atlasCopco && $ac200Model) {
                Machine::updateOrCreate(
                    ['idMachine' => "COMP-{$plantLetter}-{$counter}"],
                    [
                        'plant_id' => $room->plant_id ?? 1,
                        'process_id' => $room->process_id ?? 1,
                        'line_id' => $room->line_id ?? 1,
                        'room_id' => $room->id,
                        'type_id' => $compressor->id,
                        'brand_id' => $atlasCopco->id,
                        'model_id' => $ac200Model->id,
                        'serial_number' => "AC200-{$year}-{$plantLetter}-" . str_pad($counter++, 3, '0', STR_PAD_LEFT),
                        'tahun_production' => $year,
                        'no_document' => "DOC-COMP-{$plantLetter}-" . str_pad($counter - 1, 3, '0', STR_PAD_LEFT),
                        'photo' => null
                    ]
                );

                Machine::updateOrCreate(
                    ['idMachine' => "COMP-{$plantLetter}-{$counter}"],
                    [
                        'plant_id' => $room->plant_id ?? 1,
                        'process_id' => $room->process_id ?? 1,
                        'line_id' => $room->line_id ?? 1,
                        'room_id' => $room->id,
                        'type_id' => $compressor->id,
                        'brand_id' => $atlasCopco->id,
                        'model_id' => $ac200Model->id,
                        'serial_number' => "AC200-{$year}-{$plantLetter}-" . str_pad($counter++, 3, '0', STR_PAD_LEFT),
                        'tahun_production' => $year,
                        'no_document' => "DOC-COMP-{$plantLetter}-" . str_pad($counter - 1, 3, '0', STR_PAD_LEFT),
                        'photo' => null
                    ]
                );
            }

            // Blower Exhaust (1 unit)
            if ($blower && $gardnerDenver && $be500Model) {
                Machine::updateOrCreate(
                    ['idMachine' => "BLWR-{$plantLetter}-{$counter}"],
                    [
                        'plant_id' => $room->plant_id ?? 1,
                        'process_id' => $room->process_id ?? 1,
                        'line_id' => $room->line_id ?? 1,
                        'room_id' => $room->id,
                        'type_id' => $blower->id,
                        'brand_id' => $gardnerDenver->id,
                        'model_id' => $be500Model->id,
                        'serial_number' => "BE500-{$year}-{$plantLetter}-" . str_pad($counter++, 3, '0', STR_PAD_LEFT),
                        'tahun_production' => $year,
                        'no_document' => "DOC-BLWR-{$plantLetter}-" . str_pad($counter - 1, 3, '0', STR_PAD_LEFT),
                        'photo' => null
                    ]
                );
            }

            // Boiler (1 unit)
            if ($boiler && $bosch && $bl1000Model) {
                Machine::updateOrCreate(
                    ['idMachine' => "BOIL-{$plantLetter}-{$counter}"],
                    [
                        'plant_id' => $room->plant_id ?? 1,
                        'process_id' => $room->process_id ?? 1,
                        'line_id' => $room->line_id ?? 1,
                        'room_id' => $room->id,
                        'type_id' => $boiler->id,
                        'brand_id' => $bosch->id,
                        'model_id' => $bl1000Model->id,
                        'serial_number' => "BL1000-{$year}-{$plantLetter}-" . str_pad($counter++, 3, '0', STR_PAD_LEFT),
                        'tahun_production' => $year,
                        'no_document' => "DOC-BOIL-{$plantLetter}-" . str_pad($counter - 1, 3, '0', STR_PAD_LEFT),
                        'photo' => null
                    ]
                );
            }

            // Generator Set (1 unit)
            if ($genset && $cummins && $genset500Model) {
                Machine::updateOrCreate(
                    ['idMachine' => "GENS-{$plantLetter}-{$counter}"],
                    [
                        'plant_id' => $room->plant_id ?? 1,
                        'process_id' => $room->process_id ?? 1,
                        'line_id' => $room->line_id ?? 1,
                        'room_id' => $room->id,
                        'type_id' => $genset->id,
                        'brand_id' => $cummins->id,
                        'model_id' => $genset500Model->id,
                        'serial_number' => "GENSET500-{$year}-{$plantLetter}-" . str_pad($counter++, 3, '0', STR_PAD_LEFT),
                        'tahun_production' => $year,
                        'no_document' => "DOC-GENS-{$plantLetter}-" . str_pad($counter - 1, 3, '0', STR_PAD_LEFT),
                        'photo' => null
                    ]
                );
            }
        };

        // Create machines for each Utility Room
        $createMachinesInRoom($utilityRoomA, 'Utility Room Plant A', 'A');
        $createMachinesInRoom($utilityRoomB, 'Utility Room Plant B', 'B');
        $createMachinesInRoom($utilityRoomC, 'Utility Room Plant C', 'C');
        $createMachinesInRoom($utilityRoomD, 'Utility Room Plant D', 'D');
    }
}
