<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Machine;
use App\Models\Plant;
use App\Models\Process;
use App\Models\Line;
use App\Models\Room;
use App\Models\MachineType;
use App\Models\Brand;
use App\Models\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ImportMachinesFromDowntimeCsvSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $csvPath = base_path('downtime2024revisi.csv');
        
        if (!file_exists($csvPath)) {
            $this->command->error("File CSV tidak ditemukan: {$csvPath}");
            return;
        }

        $this->command->info("Membaca file CSV...");
        
        // Baca file CSV
        $file = fopen($csvPath, 'r');
        if (!$file) {
            $this->command->error("Tidak dapat membuka file CSV");
            return;
        }

        // Baca header
        $headers = fgetcsv($file, 0, "\t");
        if (!$headers) {
            $this->command->error("Tidak dapat membaca header CSV");
            fclose($file);
            return;
        }

        // Map header ke index
        $headerMap = array_flip($headers);
        
        $requiredColumns = ['plant', 'process', 'line', 'roomName', 'idMachine', 'typeMachine', 'modelMachine', 'brandMachine'];
        foreach ($requiredColumns as $col) {
            if (!isset($headerMap[$col])) {
                $this->command->error("Kolom '{$col}' tidak ditemukan di CSV");
                fclose($file);
                return;
            }
        }

        // Simpan data unik berdasarkan idMachine
        $uniqueMachines = [];
        $rowCount = 0;
        $skippedCount = 0;

        while (($row = fgetcsv($file, 0, "\t")) !== false) {
            $rowCount++;
            
            if (count($row) < count($headers)) {
                continue; // Skip invalid rows
            }

            $idMachine = trim($row[$headerMap['idMachine']] ?? '');
            $plantName = trim($row[$headerMap['plant']] ?? '');
            $processName = trim($row[$headerMap['process']] ?? '');
            $lineName = trim($row[$headerMap['line']] ?? '');
            $roomName = trim($row[$headerMap['roomName']] ?? '');
            $typeMachine = trim($row[$headerMap['typeMachine']] ?? '');
            $modelMachine = trim($row[$headerMap['modelMachine']] ?? '');
            $brandMachine = trim($row[$headerMap['brandMachine']] ?? '');

            // Skip jika idMachine kosong
            if (empty($idMachine)) {
                $skippedCount++;
                continue;
            }

            // Simpan data unik (ambil yang pertama jika ada duplikat)
            if (!isset($uniqueMachines[$idMachine])) {
                $uniqueMachines[$idMachine] = [
                    'idMachine' => $idMachine,
                    'plant' => $plantName,
                    'process' => $processName,
                    'line' => $lineName,
                    'roomName' => $roomName,
                    'typeMachine' => $typeMachine,
                    'modelMachine' => $modelMachine,
                    'brandMachine' => $brandMachine,
                ];
            }
        }

        fclose($file);

        $this->command->info("Total baris dibaca: {$rowCount}");
        $this->command->info("Baris dilewati: {$skippedCount}");
        $this->command->info("Mesin unik ditemukan: " . count($uniqueMachines));

        // Import machines
        $imported = 0;
        $skipped = 0;
        $errors = [];

        DB::beginTransaction();
        try {
            foreach ($uniqueMachines as $machineData) {
                try {
                    // Cari Plant
                    $plant = Plant::where('name', $machineData['plant'])->first();
                    if (!$plant) {
                        $errors[] = "Plant '{$machineData['plant']}' tidak ditemukan untuk mesin {$machineData['idMachine']}";
                        $skipped++;
                        continue;
                    }

                    // Cari Process
                    $process = Process::where('name', $machineData['process'])->first();
                    if (!$process) {
                        $errors[] = "Process '{$machineData['process']}' tidak ditemukan untuk mesin {$machineData['idMachine']}";
                        $skipped++;
                        continue;
                    }

                    // Cari Line (harus sesuai dengan plant)
                    $line = Line::where('name', $machineData['line'])
                        ->where('plant_id', $plant->id)
                        ->first();
                    
                    // Jika Line tidak ditemukan, buat Line baru
                    if (!$line) {
                        $line = Line::create([
                            'name' => $machineData['line'],
                            'plant_id' => $plant->id,
                            'process_id' => $process->id,
                        ]);
                        $this->command->info("Created Line: {$machineData['line']} for Plant {$plant->name}");
                    }

                    // Cari Room (harus sesuai dengan plant, line, dan roomName)
                    $room = Room::where('name', $machineData['roomName'])
                        ->where('plant_id', $plant->id)
                        ->where('line_id', $line->id)
                        ->first();
                    
                    if (!$room) {
                        // Jika tidak ditemukan, coba cari tanpa line_id (fallback)
                        $room = Room::where('name', $machineData['roomName'])
                            ->where('plant_id', $plant->id)
                            ->first();
                    }
                    
                    // Jika Room tidak ditemukan, buat Room baru
                    if (!$room) {
                        $room = Room::create([
                            'name' => $machineData['roomName'],
                            'plant_id' => $plant->id,
                            'line_id' => $line->id,
                            'process_id' => $process->id, // Tambahkan process_id jika ada di tabel
                            'category' => null,
                            'description' => null,
                        ]);
                        $this->command->info("Created Room: {$machineData['roomName']} for Plant {$plant->name}, Line {$line->name}");
                    }

                    // Cari atau buat MachineType
                    $machineType = MachineType::firstOrCreate(
                        ['name' => $machineData['typeMachine']],
                        ['name' => $machineData['typeMachine']]
                    );

                    // Cari atau buat Brand
                    $brand = Brand::firstOrCreate(
                        ['name' => $machineData['brandMachine']],
                        ['name' => $machineData['brandMachine']]
                    );

                    // Cari atau buat Model (harus sesuai dengan type dan brand)
                    $model = Model::where('name', $machineData['modelMachine'])
                        ->where('type_id', $machineType->id)
                        ->where('brand_id', $brand->id)
                        ->first();
                    
                    if (!$model) {
                        $model = Model::create([
                            'name' => $machineData['modelMachine'],
                            'type_id' => $machineType->id,
                            'brand_id' => $brand->id,
                        ]);
                    }

                    // Cek apakah machine sudah ada
                    $existingMachine = Machine::where('idMachine', $machineData['idMachine'])->first();
                    
                    if ($existingMachine) {
                        // Update existing machine
                        $existingMachine->update([
                            'plant_id' => $plant->id,
                            'process_id' => $process->id,
                            'line_id' => $line->id,
                            'room_id' => $room->id,
                            'type_id' => $machineType->id,
                            'brand_id' => $brand->id,
                            'model_id' => $model->id,
                        ]);
                        $this->command->info("Updated: {$machineData['idMachine']}");
                    } else {
                        // Create new machine
                        Machine::create([
                            'idMachine' => $machineData['idMachine'],
                            'plant_id' => $plant->id,
                            'process_id' => $process->id,
                            'line_id' => $line->id,
                            'room_id' => $room->id,
                            'type_id' => $machineType->id,
                            'brand_id' => $brand->id,
                            'model_id' => $model->id,
                        ]);
                        $imported++;
                    }

                } catch (\Exception $e) {
                    $errors[] = "Error pada mesin {$machineData['idMachine']}: " . $e->getMessage();
                    $skipped++;
                    Log::error("Error importing machine {$machineData['idMachine']}: " . $e->getMessage());
                }
            }

            DB::commit();

            $this->command->info("\n=== Hasil Import ===");
            $this->command->info("Berhasil diimport: {$imported}");
            $this->command->info("Dilewati: {$skipped}");
            
            if (!empty($errors)) {
                $this->command->warn("\n=== Errors (" . count($errors) . ") ===");
                foreach (array_slice($errors, 0, 20) as $error) {
                    $this->command->warn("- {$error}");
                }
                if (count($errors) > 20) {
                    $this->command->warn("... dan " . (count($errors) - 20) . " error lainnya");
                }
            }

        } catch (\Exception $e) {
            DB::rollBack();
            $this->command->error("Error: " . $e->getMessage());
            Log::error("Error in ImportMachinesFromDowntimeCsvSeeder: " . $e->getMessage());
        }
    }
}
