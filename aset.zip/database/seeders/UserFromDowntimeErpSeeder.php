<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\DowntimeErp;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class UserFromDowntimeErpSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Ambil semua nama unik beserta NIK dari downtime_erp
        $mekanikData = DowntimeErp::whereNotNull('nameMekanik')
            ->where('nameMekanik', '!=', '')
            ->where('nameMekanik', '!=', '-')
            ->whereNotNull('idMekanik')
            ->where('idMekanik', '!=', '')
            ->where('idMekanik', '!=', '-')
            ->select('nameMekanik', 'idMekanik')
            ->distinct()
            ->get()
            ->groupBy('nameMekanik')
            ->map(function ($group) {
                // Ambil idMekanik pertama yang valid (5 digit)
                return $group->first()->idMekanik;
            })
            ->toArray();
        
        $mekanikNames = array_keys($mekanikData);

        $leaderData = DowntimeErp::whereNotNull('nameLeader')
            ->where('nameLeader', '!=', '')
            ->where('nameLeader', '!=', '-')
            ->whereNotNull('idLeader')
            ->where('idLeader', '!=', '')
            ->where('idLeader', '!=', '-')
            ->select('nameLeader', 'idLeader')
            ->distinct()
            ->get()
            ->groupBy('nameLeader')
            ->map(function ($group) {
                // Ambil idLeader pertama yang valid (5 digit)
                return $group->first()->idLeader;
            })
            ->toArray();
        
        $leaderNames = array_keys($leaderData);

        // Cek apakah ada field nameGL di tabel
        $hasNameGL = DB::getSchemaBuilder()->hasColumn('downtime_erp', 'nameGL');
        $hasIdGL = DB::getSchemaBuilder()->hasColumn('downtime_erp', 'idGL');
        
        $groupLeaderData = [];
        $groupLeaderNames = [];
        if ($hasNameGL) {
            $query = DowntimeErp::whereNotNull('nameGL')
                ->where('nameGL', '!=', '')
                ->where('nameGL', '!=', '-');
            
            if ($hasIdGL) {
                $query->whereNotNull('idGL')
                    ->where('idGL', '!=', '')
                    ->where('idGL', '!=', '-');
            }
            
            $groupLeaderData = $query->select('nameGL', $hasIdGL ? 'idGL' : DB::raw('NULL as idGL'))
                ->distinct()
                ->get()
                ->groupBy('nameGL')
                ->map(function ($group) use ($hasIdGL) {
                    return $hasIdGL ? $group->first()->idGL : null;
                })
                ->toArray();
            
            $groupLeaderNames = array_keys($groupLeaderData);
        }

        $coordData = DowntimeErp::whereNotNull('nameCoord')
            ->where('nameCoord', '!=', '')
            ->where('nameCoord', '!=', '-')
            ->whereNotNull('idCoord')
            ->where('idCoord', '!=', '')
            ->where('idCoord', '!=', '-')
            ->select('nameCoord', 'idCoord')
            ->distinct()
            ->get()
            ->groupBy('nameCoord')
            ->map(function ($group) {
                // Ambil idCoord pertama yang valid (5 digit)
                return $group->first()->idCoord;
            })
            ->toArray();
        
        $coordNames = array_keys($coordData);

        // Daftar Group Leader yang ditentukan (jangan generate random lagi)
        $specifiedGLNames = ['SUPRIYANTO', 'NASAR', 'TASMAN', 'HANDHIS', 'BUDIMAN'];
        
        // Gabungkan dengan nameGL dari database jika ada
        $groupLeaderNames = array_unique(array_merge($groupLeaderNames, $specifiedGLNames));
        
        if (!empty($groupLeaderNames)) {
            $this->command->info("Group Leaders to be created: " . implode(', ', $groupLeaderNames));
        }

        // Gabungkan semua nama dan hapus duplikat
        $allNames = array_unique(array_merge($mekanikNames, $leaderNames, $groupLeaderNames, $coordNames));

        // Mapping nama ke NIK
        $nameToNik = [];
        foreach ($mekanikData as $name => $nik) {
            $nameToNik[$name] = $nik;
        }
        foreach ($leaderData as $name => $nik) {
            if (!isset($nameToNik[$name])) {
                $nameToNik[$name] = $nik;
            }
        }
        foreach ($groupLeaderData as $name => $nik) {
            if (!isset($nameToNik[$name]) && $nik) {
                $nameToNik[$name] = $nik;
            }
        }
        foreach ($coordData as $name => $nik) {
            if (!isset($nameToNik[$name])) {
                $nameToNik[$name] = $nik;
            }
        }

        // Tentukan role untuk setiap nama berdasarkan hierarki jabatan
        // Hierarki: Mekanik (terendah) < Team Leader < Group Leader < Coordinator (tertinggi)
        $nameRoles = [];
        
        // 1. Jika nama ada di mekanik, set sebagai mekanik (prioritas terendah)
        foreach ($mekanikNames as $name) {
            if (!isset($nameRoles[$name])) {
                $nameRoles[$name] = 'mekanik';
            }
        }
        
        // 2. Jika nama ada di leader, set sebagai team_leader (prioritas menengah)
        // JANGAN UBAH team_leader yang sudah ada, biar apa adanya
        foreach ($leaderNames as $name) {
            if (!isset($nameRoles[$name])) {
                $nameRoles[$name] = 'team_leader';
            }
            // Jika sudah ada role, jangan diubah (biar apa adanya)
        }
        
        // 3. Daftar Group Leader yang ditentukan
        $specifiedGLNames = ['SUPRIYANTO', 'NASAR', 'TASMAN', 'HANDHIS', 'BUDIMAN'];
        
        // 3a. Tambahkan Group Leader yang ditentukan ke daftar
        // KECUALI BUDIMAN - karena BUDIMAN yang ada di nameLeader harus tetap team_leader
        foreach ($specifiedGLNames as $glName) {
            if ($glName === 'BUDIMAN') {
                // BUDIMAN khusus: jangan override role jika sudah ada sebagai team_leader
                // Hanya tambahkan ke daftar untuk dibuat user baru nanti
                if (!in_array($glName, $groupLeaderNames)) {
                    $groupLeaderNames[] = $glName;
                }
                // Jangan set role di sini, biarkan tetap team_leader jika sudah ada
                // User baru BUDIMAN akan dibuat dengan role group_leader nanti
            } else {
                if (!in_array($glName, $groupLeaderNames)) {
                    $groupLeaderNames[] = $glName;
                }
                // Set role sebagai group_leader (override jika sudah ada role lebih rendah)
                if (!isset($nameRoles[$glName]) || in_array($nameRoles[$glName], ['mekanik', 'team_leader'])) {
                    $nameRoles[$glName] = 'group_leader';
                }
            }
        }
        
        // 3b. Jika ada nameGL dari database, gunakan juga
        foreach ($groupLeaderNames as $name) {
            if (!isset($nameRoles[$name]) || in_array($nameRoles[$name], ['mekanik', 'team_leader'])) {
                $nameRoles[$name] = 'group_leader';
            }
        }
        
        // 4. Jika nama ada di coordinator, set sebagai coordinator (prioritas tertinggi)
        foreach ($coordNames as $name) {
            $nameRoles[$name] = 'coordinator';
        }

        // Daftar nama yang perlu dibuat duplikat (nama sama, user berbeda)
        $duplicateNames = ['BUDIMAN']; // BUDIMAN ada 2 orang berbeda
        
        // Buat user untuk setiap nama
        foreach ($allNames as $name) {
            // Skip jika nama kosong atau hanya karakter khusus
            if (empty(trim($name)) || trim($name) === '-') {
                continue;
            }

            // Tentukan role
            $role = $nameRoles[$name] ?? 'mekanik';
            
            // Untuk nama yang perlu duplikat, buat beberapa user
            if (in_array($name, $duplicateNames)) {
                // Khusus untuk BUDIMAN:
                // - BUDIMAN yang ada di nameLeader tetap sebagai team_leader (jangan diubah)
                // - BUDIMAN baru dibuat sebagai group_leader
                
                // Hitung berapa banyak user dengan nama ini yang sudah ada
                $existingCount = User::where('name', $name)->count();
                $targetCount = 2; // BUDIMAN perlu 2 user
                
                // Untuk BUDIMAN, pastikan ada 1 yang team_leader dan 1 yang group_leader
                if ($name === 'BUDIMAN') {
                    $existingUsers = User::where('name', $name)->get();
                    $hasTeamLeader = $existingUsers->contains('role', 'team_leader');
                    $hasGroupLeader = $existingUsers->contains('role', 'group_leader');
                    
                    // Pastikan BUDIMAN yang dari nameLeader tetap sebagai team_leader
                    // Cari user yang sudah ada sebagai team_leader atau yang pertama kali dibuat
                    if ($existingCount > 0) {
                        $teamLeaderUser = $existingUsers->firstWhere('role', 'team_leader');
                        
                        if (!$teamLeaderUser) {
                            // Jika tidak ada yang team_leader, set yang pertama sebagai team_leader
                            $firstUser = $existingUsers->first();
                            if ($firstUser->role !== 'team_leader') {
                                $firstUser->role = 'team_leader';
                                $firstUser->save();
                                $this->command->info("Set first BUDIMAN ({$firstUser->email}) as team_leader (from nameLeader)");
                            }
                        } else {
                            // Pastikan yang sudah team_leader tetap team_leader
                            $this->command->line("Keeping BUDIMAN ({$teamLeaderUser->email}) as team_leader (from nameLeader)");
                        }
                    }
                    
                    // Buat user baru sebagai group_leader jika belum ada
                    if (!$hasGroupLeader) {
                        $baseEmail = Str::slug($name, '.');
                        $email = $baseEmail . '@tpm.local';
                        
                        // Jika email sudah ada, tambahkan angka
                        $counter = 1;
                        while (User::where('email', $email)->exists()) {
                            $email = $baseEmail . $counter . '@tpm.local';
                            $counter++;
                        }

                        // Buat user baru sebagai group_leader
                        $nik = $nameToNik[$name] ?? null;
                        // Pastikan NIK 5 digit, jika tidak valid, buat NIK random
                        if (!$nik || strlen($nik) != 5 || !preg_match('/^[0-9]{5}$/', $nik)) {
                            // Generate NIK random 5 digit jika tidak ada atau tidak valid
                            do {
                                $nik = str_pad(rand(10000, 99999), 5, '0', STR_PAD_LEFT);
                            } while (User::where('nik', $nik)->exists());
                        } else {
                            // Pastikan NIK unique
                            if (User::where('nik', $nik)->exists()) {
                                do {
                                    $nik = str_pad(rand(10000, 99999), 5, '0', STR_PAD_LEFT);
                                } while (User::where('nik', $nik)->exists());
                            }
                        }
                        
                        User::create([
                            'nik' => $nik,
                            'name' => $name,
                            'email' => $email,
                            'password' => Hash::make('password123'),
                            'role' => 'group_leader',
                        ]);

                        $this->command->info("Created user: {$name} ({$email}) - NIK: {$nik} - Role: group_leader [New GL]");
                    } else {
                        // Pastikan yang sudah group_leader tetap group_leader
                        $groupLeaderUser = $existingUsers->firstWhere('role', 'group_leader');
                        if ($groupLeaderUser) {
                            $this->command->line("BUDIMAN ({$groupLeaderUser->email}) already exists as group_leader");
                        }
                    }
                } else {
                    // Untuk duplikat nama lain (bukan BUDIMAN), buat user tambahan
                    for ($i = $existingCount; $i < $targetCount; $i++) {
                        $baseEmail = Str::slug($name, '.');
                        $email = $baseEmail . '@tpm.local';
                        
                        $counter = 1;
                        while (User::where('email', $email)->exists()) {
                            $email = $baseEmail . $counter . '@tpm.local';
                            $counter++;
                        }

                        User::create([
                            'name' => $name,
                            'email' => $email,
                            'password' => Hash::make('password123'),
                            'role' => $role,
                        ]);

                        $this->command->info("Created user: {$name} ({$email}) - Role: {$role} [Duplicate #" . ($i + 1) . "]");
                    }
                }
                
                continue; // Skip ke nama berikutnya
            }

            // Cek apakah user dengan nama ini sudah ada (untuk nama non-duplikat)
            $existingUser = User::where('name', $name)->first();
            
            if (!$existingUser) {
                // Generate email dari nama (lowercase, replace space dengan dot)
                $baseEmail = Str::slug($name, '.');
                $email = $baseEmail . '@tpm.local';
                
                // Jika email sudah ada, tambahkan angka
                $counter = 1;
                while (User::where('email', $email)->exists()) {
                    $email = $baseEmail . $counter . '@tpm.local';
                    $counter++;
                }

                // Tentukan role
                $role = $nameRoles[$name] ?? 'mekanik';
                
                // Ambil NIK dari mapping
                $nik = $nameToNik[$name] ?? null;
                // Pastikan NIK 5 digit, jika tidak valid, buat NIK random
                if (!$nik || strlen($nik) != 5 || !preg_match('/^[0-9]{5}$/', $nik)) {
                    // Generate NIK random 5 digit jika tidak ada atau tidak valid
                    do {
                        $nik = str_pad(rand(10000, 99999), 5, '0', STR_PAD_LEFT);
                    } while (User::where('nik', $nik)->exists());
                } else {
                    // Pastikan NIK unique
                    if (User::where('nik', $nik)->exists()) {
                        // Jika NIK sudah ada, generate yang baru
                        do {
                            $nik = str_pad(rand(10000, 99999), 5, '0', STR_PAD_LEFT);
                        } while (User::where('nik', $nik)->exists());
                    }
                }

                // Buat user baru
                User::create([
                    'nik' => $nik,
                    'name' => $name,
                    'email' => $email,
                    'password' => Hash::make('password123'), // Default password, bisa diubah nanti
                    'role' => $role,
                ]);

                $this->command->info("Created user: {$name} ({$email}) - Role: {$role}");
            } else {
                // Update NIK jika belum ada dan ada di mapping
                if (empty($existingUser->nik) && isset($nameToNik[$name])) {
                    $nik = $nameToNik[$name];
                    if (strlen($nik) == 5 && preg_match('/^[0-9]{5}$/', $nik)) {
                        // Pastikan NIK unique
                        if (!User::where('nik', $nik)->where('id', '!=', $existingUser->id)->exists()) {
                            $existingUser->nik = $nik;
                            $existingUser->save();
                            $this->command->info("Updated NIK for user: {$name} - NIK: {$nik}");
                        }
                    }
                }
                
                // Update role jika user sudah ada
                $suggestedRole = $nameRoles[$name] ?? $existingUser->role;
                
                // Daftar Group Leader yang ditentukan (bisa override team_leader)
                $specifiedGLNames = ['SUPRIYANTO', 'NASAR', 'TASMAN', 'HANDHIS', 'BUDIMAN'];
                
                // JANGAN UBAH team_leader yang sudah ada, biar apa adanya
                // KECUALI jika nama tersebut adalah Group Leader yang ditentukan
                if ($existingUser->role === 'team_leader' && $suggestedRole !== 'team_leader') {
                    if (in_array($name, $specifiedGLNames)) {
                        // Group Leader yang ditentukan bisa override team_leader
                        $this->command->info("Updating {$name} from team_leader to group_leader (specified GL)");
                    } else {
                        $this->command->line("User already exists: {$name} (Role: {$existingUser->role}) - Keeping as Team Leader");
                        continue;
                    }
                }
                
                // Hierarki role untuk update
                $roleHierarchy = [
                    'mekanik' => 1,
                    'team_leader' => 2,
                    'group_leader' => 3,
                    'coordinator' => 4
                ];
                
                $currentLevel = $roleHierarchy[$existingUser->role] ?? 0;
                $suggestedLevel = $roleHierarchy[$suggestedRole] ?? 0;
                
                // Update jika suggested role lebih tinggi, atau jika adalah Group Leader yang ditentukan
                if ($suggestedLevel > $currentLevel || in_array($name, $specifiedGLNames)) {
                    $existingUser->role = $suggestedRole;
                    $existingUser->save();
                    $this->command->info("Updated role for user: {$name} - New role: {$suggestedRole}");
                } else {
                    $this->command->line("User already exists: {$name} (Role: {$existingUser->role})");
                }
            }
        }

        $this->command->info("\nTotal users processed: " . count($allNames));
        $this->command->info("Role distribution:");
        $this->command->info("- Mekanik: " . count(array_filter($nameRoles, fn($r) => $r === 'mekanik')));
        $this->command->info("- Team Leader: " . count(array_filter($nameRoles, fn($r) => $r === 'team_leader')));
        $this->command->info("- Group Leader: " . count(array_filter($nameRoles, fn($r) => $r === 'group_leader')));
        $this->command->info("- Coordinator: " . count(array_filter($nameRoles, fn($r) => $r === 'coordinator')));
    }
}

