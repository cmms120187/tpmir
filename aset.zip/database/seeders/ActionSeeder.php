<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Action;

class ActionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $actions = [
            'Ganti Komponen',
            'Bersihkan Komponen',
            'Perbaikan Mekanik',
            'Perbaikan Elektrik',
            'Kalibrasi',
            'Adjustment',
            'Lubrikasi',
            'Tightening',
            'Replacement',
            'Repair',
            'Cleaning',
            'Inspection',
            'Maintenance Preventive',
            'Troubleshooting',
            'Reset System',
        ];

        foreach ($actions as $action) {
            Action::firstOrCreate(['name' => $action]);
        }
    }
}
