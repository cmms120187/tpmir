<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Admin User (General Manager)
        $generalManager = User::firstOrCreate(
            ['email' => 'wahid@tpmcmms.id'],
            [
                'nik' => '00001',
                'name' => 'Wahid N',
                'password' => Hash::make('12345678'),
                'role' => 'general_manager',
            ]
        );
        // Update fields if user exists
        $updated = false;
        if (!$generalManager->nik || $generalManager->nik !== '00001') {
            $generalManager->nik = '00001';
            $updated = true;
        }
        if ($generalManager->name !== 'Wahid N') {
            $generalManager->name = 'Wahid N';
            $updated = true;
        }
        if ($generalManager->role !== 'general_manager') {
            $generalManager->role = 'general_manager';
            $updated = true;
        }
        // Always update password to ensure it's correct
        $generalManager->password = Hash::make('12345678');
        if ($updated) {
            $generalManager->save();
        } else {
            $generalManager->save(); // Save to update password
        }

        // PIC Downtime - Mechanics (mekanik)
        $mechanics = [
            ['nik' => '10001', 'name' => 'Ahmad Rizki', 'email' => 'ahmad.rizki@tpmcmms.id'],
            ['nik' => '10002', 'name' => 'Budi Santoso', 'email' => 'budi.santoso@tpmcmms.id'],
            ['nik' => '10003', 'name' => 'Cahyo Wibowo', 'email' => 'cahyo.wibowo@tpmcmms.id'],
            ['nik' => '10004', 'name' => 'Dedi Kurniawan', 'email' => 'dedi.kurniawan@tpmcmms.id'],
            ['nik' => '10005', 'name' => 'Eko Prasetyo', 'email' => 'eko.prasetyo@tpmcmms.id'],
            ['nik' => '10006', 'name' => 'Fajar Hidayat', 'email' => 'fajar.hidayat@tpmcmms.id'],
            ['nik' => '10007', 'name' => 'Gunawan Sari', 'email' => 'gunawan.sari@tpmcmms.id'],
            ['nik' => '10008', 'name' => 'Hadi Wijaya', 'email' => 'hadi.wijaya@tpmcmms.id'],
            ['nik' => '10009', 'name' => 'Indra Setiawan', 'email' => 'indra.setiawan@tpmcmms.id'],
            ['nik' => '10010', 'name' => 'Joko Susilo', 'email' => 'joko.susilo@tpmcmms.id'],
        ];

        // PIC Downtime - Team Leaders
        $teamLeaders = [
            ['nik' => '20001', 'name' => 'Kurniawan Adi', 'email' => 'kurniawan.adi@tpmcmms.id'],
            ['nik' => '20002', 'name' => 'Lukman Hakim', 'email' => 'lukman.hakim@tpmcmms.id'],
            ['nik' => '20003', 'name' => 'Mulyadi Sari', 'email' => 'mulyadi.sari@tpmcmms.id'],
        ];

        // PIC Downtime - Group Leaders
        $groupLeaders = [
            ['nik' => '30001', 'name' => 'Nurhadi Wibowo', 'email' => 'nurhadi.wibowo@tpmcmms.id'],
            ['nik' => '30002', 'name' => 'Oki Setiawan', 'email' => 'oki.setiawan@tpmcmms.id'],
        ];

        // PIC Downtime - Coordinators
        $coordinators = [
            ['nik' => '40001', 'name' => 'Prasetyo Adi', 'email' => 'prasetyo.adi@tpmcmms.id'],
            ['nik' => '40002', 'name' => 'Rizki Kurniawan', 'email' => 'rizki.kurniawan@tpmcmms.id'],
        ];

        // Assistant Managers
        $astManagers = [
            ['nik' => '50001', 'name' => 'Sari Wijaya', 'email' => 'sari.wijaya@tpmcmms.id'],
            ['nik' => '50002', 'name' => 'Teguh Santoso', 'email' => 'teguh.santoso@tpmcmms.id'],
        ];

        // Managers
        $managers = [
            ['nik' => '60001', 'name' => 'Udin Setiawan', 'email' => 'udin.setiawan@tpmcmms.id'],
        ];

        // Ensure General Manager has no atasan
        $generalManager->atasan_id = null;
        $generalManager->role = 'general_manager';
        $generalManager->save();

        // Create managers first (they report to General Manager)
        $createdManagers = [];
        foreach ($managers as $manager) {
            $user = User::firstOrCreate(
                ['email' => $manager['email']],
                [
                    'nik' => $manager['nik'],
                    'name' => $manager['name'],
                    'password' => Hash::make('12345678'),
                    'role' => 'manager',
                    'atasan_id' => $generalManager->id,
                ]
            );
            if (!$user->nik) {
                $user->nik = $manager['nik'];
            }
            if (!$user->atasan_id) {
                $user->atasan_id = $generalManager->id;
            }
            $user->role = 'manager';
            $user->save();
            $createdManagers[] = $user;
        }

        // Create assistant managers (they report to Manager)
        $createdAstManagers = [];
        foreach ($astManagers as $index => $astManager) {
            $atasanId = isset($createdManagers[0]) ? $createdManagers[0]->id : $generalManager->id;
            $user = User::firstOrCreate(
                ['email' => $astManager['email']],
                [
                    'nik' => $astManager['nik'],
                    'name' => $astManager['name'],
                    'password' => Hash::make('12345678'),
                    'role' => 'ast_manager',
                    'atasan_id' => $atasanId,
                ]
            );
            if (!$user->nik) {
                $user->nik = $astManager['nik'];
            }
            if (!$user->atasan_id) {
                $user->atasan_id = $atasanId;
            }
            $user->role = 'ast_manager';
            $user->save();
            $createdAstManagers[] = $user;
        }

        // Create coordinators (they report to Assistant Manager)
        $createdCoordinators = [];
        foreach ($coordinators as $index => $coordinator) {
            $atasanId = isset($createdAstManagers[$index % count($createdAstManagers)])
                ? $createdAstManagers[$index % count($createdAstManagers)]->id
                : (isset($createdManagers[0]) ? $createdManagers[0]->id : $generalManager->id);
            $user = User::firstOrCreate(
                ['email' => $coordinator['email']],
                [
                    'nik' => $coordinator['nik'],
                    'name' => $coordinator['name'],
                    'password' => Hash::make('12345678'),
                    'role' => 'coordinator',
                    'atasan_id' => $atasanId,
                ]
            );
            if (!$user->nik) {
                $user->nik = $coordinator['nik'];
            }
            if (!$user->atasan_id) {
                $user->atasan_id = $atasanId;
            }
            $user->role = 'coordinator';
            $user->save();
            $createdCoordinators[] = $user;
        }

        // Create group leaders (they report to Coordinator)
        $createdGroupLeaders = [];
        foreach ($groupLeaders as $index => $groupLeader) {
            $atasanId = isset($createdCoordinators[$index % count($createdCoordinators)])
                ? $createdCoordinators[$index % count($createdCoordinators)]->id
                : (isset($createdAstManagers[0]) ? $createdAstManagers[0]->id : $generalManager->id);
            $user = User::firstOrCreate(
                ['email' => $groupLeader['email']],
                [
                    'nik' => $groupLeader['nik'],
                    'name' => $groupLeader['name'],
                    'password' => Hash::make('12345678'),
                    'role' => 'group_leader',
                    'atasan_id' => $atasanId,
                ]
            );
            if (!$user->nik) {
                $user->nik = $groupLeader['nik'];
            }
            if (!$user->atasan_id) {
                $user->atasan_id = $atasanId;
            }
            $user->role = 'group_leader';
            $user->save();
            $createdGroupLeaders[] = $user;
        }

        // Create team leaders (they report to Group Leader)
        $createdTeamLeaders = [];
        foreach ($teamLeaders as $index => $teamLeader) {
            $atasanId = isset($createdGroupLeaders[$index % count($createdGroupLeaders)])
                ? $createdGroupLeaders[$index % count($createdGroupLeaders)]->id
                : (isset($createdCoordinators[0]) ? $createdCoordinators[0]->id : $generalManager->id);
            $user = User::firstOrCreate(
                ['email' => $teamLeader['email']],
                [
                    'nik' => $teamLeader['nik'],
                    'name' => $teamLeader['name'],
                    'password' => Hash::make('12345678'),
                    'role' => 'team_leader',
                    'atasan_id' => $atasanId,
                ]
            );
            if (!$user->nik) {
                $user->nik = $teamLeader['nik'];
            }
            if (!$user->atasan_id) {
                $user->atasan_id = $atasanId;
            }
            $user->role = 'team_leader';
            $user->save();
            $createdTeamLeaders[] = $user;
        }

        // Create mechanics (they report to Team Leader)
        $createdMechanics = [];
        foreach ($mechanics as $index => $mechanic) {
            // Distribute mechanics evenly among team leaders
            $teamLeaderIndex = $index % count($createdTeamLeaders);
            $atasanId = isset($createdTeamLeaders[$teamLeaderIndex])
                ? $createdTeamLeaders[$teamLeaderIndex]->id
                : (isset($createdGroupLeaders[0]) ? $createdGroupLeaders[0]->id : $generalManager->id);

            $user = User::firstOrCreate(
                ['email' => $mechanic['email']],
                [
                    'nik' => $mechanic['nik'],
                    'name' => $mechanic['name'],
                    'password' => Hash::make('12345678'),
                    'role' => 'mekanik',
                    'atasan_id' => $atasanId,
                ]
            );
            if (!$user->nik) {
                $user->nik = $mechanic['nik'];
            }
            if (!$user->atasan_id) {
                $user->atasan_id = $atasanId;
            }
            $user->role = 'mekanik';
            $user->save();
            $createdMechanics[] = $user;
        }

        $this->command->info('Users seeded successfully with NIK and organizational structure!');
    }
}
