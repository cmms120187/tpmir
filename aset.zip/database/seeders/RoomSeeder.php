<?php

namespace Database\Seeders;

use App\Models\Plant;
use App\Models\Process;
use App\Models\Line;
use App\Models\Room;
use Illuminate\Database\Seeder;

class RoomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create 4 Plants (using firstOrCreate to avoid duplicates)
        $plantA = Plant::firstOrCreate(['name' => 'Plant A']);
        $plantB = Plant::firstOrCreate(['name' => 'Plant B']);
        $plantC = Plant::firstOrCreate(['name' => 'Plant C']);
        $plantD = Plant::firstOrCreate(['name' => 'Plant D']);

        // Create Process for Utility (using firstOrCreate to avoid duplicates)
        $processUtility = Process::firstOrCreate(['name' => 'Utility']);

        // Create Lines for each Plant - Utility Line (using firstOrCreate to avoid duplicates)
        $lineUtilityA = Line::firstOrCreate(
            ['name' => 'Utility Line', 'plant_id' => $plantA->id],
            ['process_id' => $processUtility->id]
        );
        $lineUtilityB = Line::firstOrCreate(
            ['name' => 'Utility Line', 'plant_id' => $plantB->id],
            ['process_id' => $processUtility->id]
        );
        $lineUtilityC = Line::firstOrCreate(
            ['name' => 'Utility Line', 'plant_id' => $plantC->id],
            ['process_id' => $processUtility->id]
        );
        $lineUtilityD = Line::firstOrCreate(
            ['name' => 'Utility Line', 'plant_id' => $plantD->id],
            ['process_id' => $processUtility->id]
        );

        // Create Utility Room for each Plant (using firstOrCreate to avoid duplicates)
        Room::firstOrCreate(
            ['name' => 'Utility Room Plant A'],
            [
                'plant_id' => $plantA->id,
                'process_id' => $processUtility->id,
                'line_id' => $lineUtilityA->id,
                'category' => 'Utility',
                'description' => 'Utility equipment room for Plant A - Contains compressors, blowers, boilers, and gensets'
            ]
        );

        Room::firstOrCreate(
            ['name' => 'Utility Room Plant B'],
            [
                'plant_id' => $plantB->id,
                'process_id' => $processUtility->id,
                'line_id' => $lineUtilityB->id,
                'category' => 'Utility',
                'description' => 'Utility equipment room for Plant B - Contains compressors, blowers, boilers, and gensets'
            ]
        );

        Room::firstOrCreate(
            ['name' => 'Utility Room Plant C'],
            [
                'plant_id' => $plantC->id,
                'process_id' => $processUtility->id,
                'line_id' => $lineUtilityC->id,
                'category' => 'Utility',
                'description' => 'Utility equipment room for Plant C - Contains compressors, blowers, boilers, and gensets'
            ]
        );

        Room::firstOrCreate(
            ['name' => 'Utility Room Plant D'],
            [
                'plant_id' => $plantD->id,
                'process_id' => $processUtility->id,
                'line_id' => $lineUtilityD->id,
                'category' => 'Utility',
                'description' => 'Utility equipment room for Plant D - Contains compressors, blowers, boilers, and gensets'
            ]
        );
    }
}
