<?php

namespace Database\Seeders;

use App\Models\MachineType;
use App\Models\System;
use App\Models\Group;
use Illuminate\Database\Seeder;

class MachineTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get groups
        $compressingGroup = Group::where('name', 'Compressing')->first();
        $blowerGroup = Group::where('name', 'Blower')->first();
        $boilerGroup = Group::where('name', 'Boiler')->first();
        $gensetGroup = Group::where('name', 'Genset')->first();
        $productionGroup = Group::where('name', 'Production')->first();
        $qualityControlGroup = Group::where('name', 'Quality Control')->first();

        // Get systems (for production and quality control machines that don't have groups)
        $mechanical = System::where('nama_sistem', 'Mechanical')->first();
        $electrical = System::where('nama_sistem', 'Electrical')->first();
        $pneumatic = System::where('nama_sistem', 'Pneumatic')->first();
        $electronic = System::where('nama_sistem', 'Electronic')->first();
        $cooling = System::where('nama_sistem', 'Cooling')->first();
        $lubrication = System::where('nama_sistem', 'Lubrication')->first();
        $heating = System::where('nama_sistem', 'Heating')->first();

        // Utility Machines - Only one entry per name
        $ac = MachineType::updateOrCreate(
            ['name' => 'Air Compressor'],
            [
                'model' => 'AC-200',
                'group' => 'Utility',
                'group_id' => $compressingGroup ? $compressingGroup->id : null,
                'brand' => 'Atlas Copco',
                'description' => 'Screw type air compressor for production line air supply'
            ]
        );
        // Systems will be auto-synced from group, but we can also manually sync if needed
        if ($compressingGroup && $compressingGroup->systems->isNotEmpty()) {
            $ac->systems()->sync($compressingGroup->systems->pluck('id')->toArray());
        }

        $be = MachineType::updateOrCreate(
            ['name' => 'Blower Exhaust'],
            [
                'model' => 'BE-500',
                'group' => 'Utility',
                'group_id' => $blowerGroup ? $blowerGroup->id : null,
                'brand' => 'Gardner Denver',
                'description' => 'Industrial exhaust blower for air circulation and dust removal'
            ]
        );
        if ($blowerGroup && $blowerGroup->systems->isNotEmpty()) {
            $be->systems()->sync($blowerGroup->systems->pluck('id')->toArray());
        }

        $bo = MachineType::updateOrCreate(
            ['name' => 'Boiler'],
            [
                'model' => 'BL-1000',
                'group' => 'Utility',
                'group_id' => $boilerGroup ? $boilerGroup->id : null,
                'brand' => 'Bosch',
                'description' => 'Fire tube boiler for steam generation in production process'
            ]
        );
        if ($boilerGroup && $boilerGroup->systems->isNotEmpty()) {
            $bo->systems()->sync($boilerGroup->systems->pluck('id')->toArray());
        }

        $gs = MachineType::updateOrCreate(
            ['name' => 'Generator Set'],
            [
                'model' => 'GENSET-500KVA',
                'group' => 'Utility',
                'group_id' => $gensetGroup ? $gensetGroup->id : null,
                'brand' => 'Cummins',
                'description' => '500 KVA diesel generator for backup power supply'
            ]
        );
        if ($gensetGroup && $gensetGroup->systems->isNotEmpty()) {
            $gs->systems()->sync($gensetGroup->systems->pluck('id')->toArray());
        }

        // Production Machines
        $mx = MachineType::updateOrCreate(
            ['name' => 'Mixing Machine'],
            [
                'model' => 'MX-500',
                'group' => 'Production',
                'group_id' => $productionGroup ? $productionGroup->id : null,
                'brand' => 'Hobart',
                'description' => 'Industrial mixer for raw material blending'
            ]
        );
        if ($productionGroup && $productionGroup->systems->isNotEmpty()) {
            $mx->systems()->sync($productionGroup->systems->pluck('id')->toArray());
        } else {
            $mx->systems()->sync([$mechanical->id, $electrical->id]);
        }

        $fm = MachineType::updateOrCreate(
            ['name' => 'Filling Machine'],
            [
                'model' => 'FM-200',
                'group' => 'Production',
                'group_id' => $productionGroup ? $productionGroup->id : null,
                'brand' => 'Krones',
                'description' => 'Automatic filling machine for liquid products'
            ]
        );
        if ($productionGroup && $productionGroup->systems->isNotEmpty()) {
            $fm->systems()->sync($productionGroup->systems->pluck('id')->toArray());
        } else {
            $fm->systems()->sync([$mechanical->id, $electrical->id, $pneumatic->id, $electronic->id]);
        }

        $pk = MachineType::updateOrCreate(
            ['name' => 'Packaging Machine'],
            [
                'model' => 'PK-300',
                'group' => 'Production',
                'group_id' => $productionGroup ? $productionGroup->id : null,
                'brand' => 'Bosch',
                'description' => 'Automatic packaging machine with sealing system'
            ]
        );
        if ($productionGroup && $productionGroup->systems->isNotEmpty()) {
            $pk->systems()->sync($productionGroup->systems->pluck('id')->toArray());
        } else {
            $pk->systems()->sync([$mechanical->id, $electrical->id, $pneumatic->id, $electronic->id]);
        }

        $cv = MachineType::updateOrCreate(
            ['name' => 'Conveyor Belt'],
            [
                'model' => 'CV-100',
                'group' => 'Production',
                'group_id' => $productionGroup ? $productionGroup->id : null,
                'brand' => 'Interroll',
                'description' => 'Belt conveyor for material transport'
            ]
        );
        if ($productionGroup && $productionGroup->systems->isNotEmpty()) {
            $cv->systems()->sync($productionGroup->systems->pluck('id')->toArray());
        } else {
            $cv->systems()->sync([$mechanical->id, $electrical->id]);
        }

        $lb = MachineType::updateOrCreate(
            ['name' => 'Labeling Machine'],
            [
                'model' => 'LB-150',
                'group' => 'Production',
                'group_id' => $productionGroup ? $productionGroup->id : null,
                'brand' => 'Weber',
                'description' => 'Automatic labeling machine for product labeling'
            ]
        );
        if ($productionGroup && $productionGroup->systems->isNotEmpty()) {
            $lb->systems()->sync($productionGroup->systems->pluck('id')->toArray());
        } else {
            $lb->systems()->sync([$mechanical->id, $electrical->id, $pneumatic->id, $electronic->id]);
        }

        $cp = MachineType::updateOrCreate(
            ['name' => 'Capping Machine'],
            [
                'model' => 'CP-120',
                'group' => 'Production',
                'group_id' => $productionGroup ? $productionGroup->id : null,
                'brand' => 'Krones',
                'description' => 'Automatic capping machine for bottle sealing'
            ]
        );
        if ($productionGroup && $productionGroup->systems->isNotEmpty()) {
            $cp->systems()->sync($productionGroup->systems->pluck('id')->toArray());
        } else {
            $cp->systems()->sync([$mechanical->id, $electrical->id, $pneumatic->id]);
        }

        // Quality Control Machines
        $ws = MachineType::updateOrCreate(
            ['name' => 'Weighing Scale'],
            [
                'model' => 'WS-50',
                'group' => 'Quality Control',
                'group_id' => $qualityControlGroup ? $qualityControlGroup->id : null,
                'brand' => 'Mettler Toledo',
                'description' => 'Precision weighing scale for quality control'
            ]
        );
        if ($qualityControlGroup && $qualityControlGroup->systems->isNotEmpty()) {
            $ws->systems()->sync($qualityControlGroup->systems->pluck('id')->toArray());
        } else {
            $ws->systems()->sync([$electronic->id]);
        }

        $ph = MachineType::updateOrCreate(
            ['name' => 'pH Meter'],
            [
                'model' => 'PH-200',
                'group' => 'Quality Control',
                'group_id' => $qualityControlGroup ? $qualityControlGroup->id : null,
                'brand' => 'Hanna Instruments',
                'description' => 'Digital pH meter for product quality testing'
            ]
        );
        if ($qualityControlGroup && $qualityControlGroup->systems->isNotEmpty()) {
            $ph->systems()->sync($qualityControlGroup->systems->pluck('id')->toArray());
        } else {
            $ph->systems()->sync([$electronic->id]);
        }

        $sp = MachineType::updateOrCreate(
            ['name' => 'Spectrophotometer'],
            [
                'model' => 'SP-100',
                'group' => 'Quality Control',
                'group_id' => $qualityControlGroup ? $qualityControlGroup->id : null,
                'brand' => 'Shimadzu',
                'description' => 'UV-Vis spectrophotometer for chemical analysis'
            ]
        );
        if ($qualityControlGroup && $qualityControlGroup->systems->isNotEmpty()) {
            $sp->systems()->sync($qualityControlGroup->systems->pluck('id')->toArray());
        } else {
            $sp->systems()->sync([$electronic->id]);
        }
    }
}
