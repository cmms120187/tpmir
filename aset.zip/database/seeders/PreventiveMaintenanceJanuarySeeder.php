<?php

namespace Database\Seeders;

use App\Models\PreventiveMaintenanceSchedule;
use App\Models\PreventiveMaintenanceExecution;
use App\Models\Machine;
use App\Models\MaintenancePoint;
use App\Models\User;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class PreventiveMaintenanceJanuarySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get all machines
        $machines = Machine::with('machineType')->get();

        if ($machines->isEmpty()) {
            $this->command->warn('No machines found. Please run MachineSeeder first.');
            return;
        }

        // Get users for assignment (mechanics, team leaders, group leaders, coordinators)
        $mechanics = User::where('role', 'mekanik')->get();
        $teamLeaders = User::where('role', 'team_leader')->get();
        $groupLeaders = User::where('role', 'group_leader')->get();
        $coordinators = User::where('role', 'coordinator')->get();

        $allUsers = $mechanics->merge($teamLeaders)->merge($groupLeaders)->merge($coordinators);

        if ($allUsers->isEmpty()) {
            $this->command->warn('No users found. Please run UserSeeder first.');
            return;
        }

        $schedulesCreated = 0;
        $executionsCreated = 0;
        $currentYear = 2025;

        // Date range: January to December
        $startDate = Carbon::create($currentYear, 1, 1);
        $endDate = Carbon::create($currentYear, 12, 31);

        foreach ($machines as $machine) {
            if (!$machine->machineType) {
                $this->command->warn("Machine ID {$machine->id} has no machineType. Skipping...");
                continue;
            }

            // Get maintenance points for this machine type (preventive category)
            // Use machineType->id, not machine_type_id directly
            $maintenancePoints = MaintenancePoint::where('machine_type_id', $machine->machineType->id)
                ->where('category', 'preventive')
                ->orderBy('sequence', 'asc')
                ->get();

            if ($maintenancePoints->isEmpty()) {
                $typeName = $machine->machineType->name ?? 'N/A';
                $this->command->warn("Machine ID {$machine->id} (Type: {$typeName}) has no preventive maintenance points. Skipping...");
                continue;
            }

            // Assign a random user to this machine's schedules
            $assignedUser = $allUsers->random();

            // Create schedules for each maintenance point
            foreach ($maintenancePoints as $point) {
                $frequencyType = $point->frequency_type ?? 'monthly';
                $frequencyValue = $point->frequency_value ?? 1;

                // Calculate preferred time (random between 08:00 - 16:00)
                $preferredHour = rand(8, 15);
                $preferredMinute = rand(0, 59);
                $preferredTime = Carbon::createFromTime($preferredHour, $preferredMinute);

                // Estimated duration (30-120 minutes)
                $estimatedDuration = rand(30, 120);

                // Generate schedules for the entire year (January to December)
                $currentScheduleDate = clone $startDate;
                $maxSchedulesPerPoint = 100; // Maximum schedules per maintenance point per year

                // Generate schedules for the entire year
                while ($currentScheduleDate->lte($endDate) && $currentScheduleDate->year == $currentYear) {
                    // Create schedule for this date
                    $schedule = PreventiveMaintenanceSchedule::firstOrCreate(
                        [
                            'machine_id' => $machine->id,
                            'maintenance_point_id' => $point->id,
                            'start_date' => $currentScheduleDate->format('Y-m-d'),
                        ],
                        [
                            'title' => $point->name,
                            'description' => $point->instruction ?? 'Preventive maintenance untuk ' . $point->name,
                            'frequency_type' => $frequencyType,
                            'frequency_value' => $frequencyValue,
                            'end_date' => $endDate->format('Y-m-d'),
                            'preferred_time' => $preferredTime->format('H:i:s'),
                            'estimated_duration' => $estimatedDuration,
                            'status' => 'active',
                            'assigned_to' => $assignedUser->id,
                            'notes' => null,
                        ]
                    );

                    $schedulesCreated++;

                    // Random execution status distribution:
                    // 45% completed, 25% in_progress, 15% pending, 10% skipped, 5% cancelled
                    $executionChance = rand(1, 100);
                    $executionStatus = null;

                    if ($executionChance <= 45) {
                        // Completed
                        $executionStatus = 'completed';
                    } elseif ($executionChance <= 70) {
                        // In Progress
                        $executionStatus = 'in_progress';
                    } elseif ($executionChance <= 85) {
                        // Pending
                        $executionStatus = 'pending';
                    } elseif ($executionChance <= 95) {
                        // Skipped
                        $executionStatus = 'skipped';
                    } else {
                        // Cancelled
                        $executionStatus = 'cancelled';
                    }

                    // Create execution for all schedules (past or today)
                    if ($currentScheduleDate->lte(now())) {
                        $performedBy = $allUsers->random();

                        $actualStartTime = null;
                        $actualEndTime = null;

                        if ($executionStatus == 'completed') {
                            // Actual start time: same day, between preferred time and preferred time + 2 hours
                            $actualStartTime = $currentScheduleDate->copy()
                                ->setTime($preferredHour, rand(0, 59))
                                ->addHours(rand(0, 2));

                            // Actual end time: start time + estimated duration + some variance (-15 to +30 minutes)
                            $actualEndTime = $actualStartTime->copy()
                                ->addMinutes($estimatedDuration + rand(-15, 30));
                        } elseif ($executionStatus == 'in_progress') {
                            // Actual start time: same day, between preferred time and preferred time + 2 hours
                            $actualStartTime = $currentScheduleDate->copy()
                                ->setTime($preferredHour, rand(0, 59))
                                ->addHours(rand(0, 2));

                            // No end time yet (in progress)
                            $actualEndTime = null;
                        } elseif ($executionStatus == 'skipped' || $executionStatus == 'cancelled') {
                            // For skipped/cancelled, might have start time but no end time
                            if (rand(1, 100) <= 30) {
                                $actualStartTime = $currentScheduleDate->copy()
                                    ->setTime($preferredHour, rand(0, 59))
                                    ->addHours(rand(0, 2));
                            }
                            $actualEndTime = null;
                        }

                        // Findings and actions (in Indonesian)
                        $findingsOptions = [
                            'Tidak ada masalah ditemukan',
                            'Ditemukan sedikit kotoran pada komponen',
                            'Beberapa bagian perlu perawatan lebih lanjut',
                            'Kondisi mesin normal',
                            'Ditemukan keausan ringan pada beberapa bagian',
                            'Semua komponen dalam kondisi baik',
                            'Ditemukan kebocoran kecil pada seal',
                            'Kondisi pelumasan masih baik',
                            'Tidak ada abnormalitas yang ditemukan',
                        ];

                        $actionsOptions = [
                            'Pembersihan rutin dilakukan',
                            'Pelumasan komponen dilakukan',
                            'Pemeriksaan visual selesai',
                            'Tidak ada tindakan yang diperlukan',
                            'Pembersihan dan pelumasan dilakukan',
                            'Semua komponen telah diperiksa dan dibersihkan',
                            'Penggantian seal dilakukan',
                            'Pengetatan baut dan mur dilakukan',
                            'Kalibrasi sensor dilakukan',
                        ];

                        $findings = null;
                        $actionsTaken = null;
                        $notes = null;

                        if ($executionStatus == 'completed') {
                            $findings = $findingsOptions[array_rand($findingsOptions)];
                            $actionsTaken = $actionsOptions[array_rand($actionsOptions)];
                            $notes = 'Maintenance selesai dilakukan sesuai jadwal';
                        } elseif ($executionStatus == 'in_progress') {
                            $findings = 'Sedang dalam proses maintenance';
                            $notes = 'Maintenance sedang berlangsung';
                        } elseif ($executionStatus == 'pending') {
                            $notes = 'Menunggu untuk dilakukan';
                        } elseif ($executionStatus == 'skipped') {
                            $notes = 'Maintenance dilewati karena alasan tertentu';
                        } elseif ($executionStatus == 'cancelled') {
                            $notes = 'Maintenance dibatalkan';
                        }

                        // Cost (random between 50,000 - 500,000) - only for completed
                        $cost = $executionStatus == 'completed' ? rand(50000, 500000) : null;

                        // Checklist - more detailed for completed
                        $checklist = [];
                        if ($executionStatus == 'completed') {
                            $checklist = [
                                [
                                    'item' => 'Pemeriksaan visual komponen',
                                    'checked' => true,
                                    'notes' => 'Selesai dilakukan',
                                ],
                                [
                                    'item' => 'Pembersihan komponen',
                                    'checked' => true,
                                    'notes' => 'Selesai dilakukan',
                                ],
                                [
                                    'item' => 'Pelumasan komponen',
                                    'checked' => true,
                                    'notes' => 'Selesai dilakukan',
                                ],
                                [
                                    'item' => 'Pemeriksaan baut dan mur',
                                    'checked' => rand(0, 100) <= 80, // 80% chance checked
                                    'notes' => rand(0, 100) <= 80 ? 'Selesai dilakukan' : null,
                                ],
                            ];
                        } elseif ($executionStatus == 'in_progress') {
                            $checklist = [
                                [
                                    'item' => 'Pemeriksaan visual komponen',
                                    'checked' => true,
                                    'notes' => 'Sedang dilakukan',
                                ],
                                [
                                    'item' => 'Pembersihan komponen',
                                    'checked' => rand(0, 100) <= 50, // 50% chance checked
                                    'notes' => null,
                                ],
                                [
                                    'item' => 'Pelumasan komponen',
                                    'checked' => false,
                                    'notes' => null,
                                ],
                            ];
                        } else {
                            // For pending, skipped, cancelled - empty or partial checklist
                            $checklist = [
                                [
                                    'item' => $point->name,
                                    'checked' => false,
                                    'notes' => null,
                                ],
                            ];
                        }

                        PreventiveMaintenanceExecution::firstOrCreate(
                            [
                                'schedule_id' => $schedule->id,
                                'scheduled_date' => $currentScheduleDate->format('Y-m-d'),
                            ],
                            [
                                'actual_start_time' => $actualStartTime ? $actualStartTime->format('Y-m-d H:i:s') : null,
                                'actual_end_time' => $actualEndTime ? $actualEndTime->format('Y-m-d H:i:s') : null,
                                'status' => $executionStatus,
                                'performed_by' => $performedBy->id,
                                'findings' => $findings,
                                'actions_taken' => $actionsTaken,
                                'notes' => $notes,
                                'checklist' => $checklist,
                                'cost' => $cost,
                                'photo_before' => null,
                                'photo_after' => null,
                            ]
                        );

                        $executionsCreated++;
                    }

                    // Calculate next schedule date based on frequency
                    $nextScheduleDate = $this->calculateNextDate($currentScheduleDate, $frequencyType, $frequencyValue);
                    
                    // If next date is beyond the year, break
                    if ($nextScheduleDate->year != $currentYear || $nextScheduleDate->gt($endDate)) {
                        break;
                    }
                    
                    $currentScheduleDate = $nextScheduleDate;

                    // Safety check to prevent infinite loop
                    if ($schedulesCreated > 5000) {
                        break 2; // Break both loops
                    }
                }
            }
        }

        $this->command->info("Preventive Maintenance Seeder (January-December) completed:");
        $this->command->info("- Schedules created: {$schedulesCreated}");
        $this->command->info("- Executions created: {$executionsCreated}");
        $this->command->info("- Status distribution:");
        
        // Show status distribution by month
        for ($month = 1; $month <= 12; $month++) {
            $statusCounts = PreventiveMaintenanceExecution::whereHas('schedule', function($query) use ($currentYear, $month) {
                $query->whereYear('start_date', $currentYear)
                      ->whereMonth('start_date', $month);
            })->selectRaw('status, count(*) as count')
              ->groupBy('status')
              ->pluck('count', 'status')
              ->toArray();
            
            if (!empty($statusCounts)) {
                $monthName = Carbon::create($currentYear, $month, 1)->format('F');
                $this->command->info("  {$monthName}:");
                foreach ($statusCounts as $status => $count) {
                    $this->command->info("    - {$status}: {$count}");
                }
            }
        }
    }

    private function calculateNextDate($currentDate, $frequencyType, $frequencyValue = 1)
    {
        $next = clone $currentDate;

        switch ($frequencyType) {
            case 'daily':
                $next->addDays($frequencyValue);
                break;
            case 'weekly':
                $next->addWeeks($frequencyValue);
                break;
            case 'monthly':
                $next->addMonths($frequencyValue);
                break;
            case 'quarterly':
                $next->addMonths($frequencyValue * 3);
                break;
            case 'yearly':
                $next->addYears($frequencyValue);
                break;
            default:
                // Default to monthly
                $next->addMonths($frequencyValue);
                break;
        }

        return $next;
    }
}
