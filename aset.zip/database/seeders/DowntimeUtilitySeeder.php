<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Downtime;
use App\Models\Machine;
use App\Models\MachineType;
use App\Models\Problem;
use App\Models\Reason;
use App\Models\Action;
use App\Models\Group;
use App\Models\User;
use App\Models\Part;
use Carbon\Carbon;

class DowntimeUtilitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get Utility Machine Types
        $compressorType = MachineType::where('name', 'Air Compressor')->first();
        $blowerType = MachineType::where('name', 'Blower Exhaust')->first();
        $boilerType = MachineType::where('name', 'Boiler')->first();
        $gensetType = MachineType::where('name', 'Generator Set')->first();

        if (!$compressorType || !$blowerType || !$boilerType || !$gensetType) {
            $this->command->error('Utility machine types not found. Please run MachineTypeSeeder first.');
            return;
        }

        // Get all utility machines (from machines table, filtered by type)
        $utilityMachines = Machine::whereIn('type_id', [
            $compressorType->id,
            $blowerType->id,
            $boilerType->id,
            $gensetType->id
        ])->with('room', 'machineType')->get();

        if ($utilityMachines->isEmpty()) {
            $this->command->error('No utility machines found. Please run MachineSeeder first.');
            return;
        }

        $this->command->info("Found {$utilityMachines->count()} utility machines");

        // Get problems (grouped by machine type for better mapping)
        $allProblems = Problem::all()->keyBy('name');
        
        // Map problems to machine types
        $problemMachineTypeMap = [
            'Air Compressor' => [
                'Kompresor Overheating',
                'Kebocoran Udara di Sistem',
                'Motor Kompresor Rusak',
                'Filter Oli Kompresor Tersumbat',
                'Pressure Switch Bermasalah',
                'Belt Slippage',
                'Aftercooler Tidak Berfungsi',
            ],
            'Blower Exhaust' => [
                'Impeller Blower Rusak',
                'Bearing Motor Rusak',
                'V-Belt Putus',
                'Motor Blower Overload',
                'Aliran Udara Tidak Cukup',
            ],
            'Boiler' => [
                'Level Air Boiler Rendah',
                'Nozzle Burner Tersumbat',
                'Temperature Controller Rusak',
                'Safety Valve Bocor',
                'Heating Element Terbakar',
                'Pressure Gauge Rusak',
                'Thermocouple Bermasalah',
                'Insulasi Boiler Rusak',
            ],
            'Generator Set' => [
                'Mesin Generator Overheating',
                'Filter Bahan Bakar Tersumbat',
                'Busi Kotor',
                'Filter Oli Generator Tersumbat',
                'Radiator Bocor',
                'Baterai Mati',
                'Alternator Rusak',
                'Fluktuasi Tegangan Generator',
            ],
        ];

        // Get reasons and actions
        $reasons = Reason::all();
        $actions = Action::all();

        if ($reasons->isEmpty() || $actions->isEmpty()) {
            $this->command->error('Reasons or Actions not found. Please run ReasonSeeder and ActionSeeder first.');
            return;
        }

        // Get groups (map by machine type)
        $compressingGroup = Group::where('name', 'Compressing')->first();
        $blowerGroup = Group::where('name', 'Blower')->first();
        $boilerGroup = Group::where('name', 'Boiler')->first();
        $gensetGroup = Group::where('name', 'Genset')->first();
        $defaultGroup = $compressingGroup ?? Group::first();

        // Get users by role
        $mechanics = User::where('role', 'mekanik')->get();
        if ($mechanics->isEmpty()) {
            $mechanics = User::take(5)->get(); // Fallback
        }

        $leaders = User::where('role', 'team_leader')->get();
        if ($leaders->isEmpty()) {
            $leaders = User::skip(5)->take(3)->get(); // Fallback
        }

        $coords = User::where('role', 'coordinator')->get();
        if ($coords->isEmpty()) {
            $coords = User::skip(8)->take(4)->get(); // Fallback
        }

        // Get parts
        $parts = Part::all();

        // Parts mapping to problems
        $problemPartMap = [
            'Filter Oli Kompresor Tersumbat' => ['Compressor Oil Filter', 'Oil Filter'],
            'Filter Oli Generator Tersumbat' => ['Generator Oil Filter', 'Oil Filter'],
            'Belt Slippage' => ['V-Belt A-50', 'Blower V-Belt'],
            'V-Belt Putus' => ['V-Belt A-50', 'Blower V-Belt'],
            'Bearing Motor Rusak' => ['Bearing 6205-2RS', 'Blower Motor Bearing'],
            'Impeller Blower Rusak' => ['Blower Impeller'],
            'Safety Valve Bocor' => ['Boiler Safety Valve'],
            'Nozzle Burner Tersumbat' => ['Boiler Burner Nozzle'],
            'Temperature Controller Rusak' => ['Boiler Temperature Controller'],
            'Heating Element Terbakar' => ['Boiler Heating Element'],
            'Pressure Gauge Rusak' => ['Boiler Pressure Gauge'],
            'Thermocouple Bermasalah' => ['Boiler Thermocouple K-Type'],
            'Insulasi Boiler Rusak' => ['Boiler Insulation Material'],
            'Busi Kotor' => ['Generator Spark Plug'],
            'Filter Bahan Bakar Tersumbat' => ['Generator Fuel Filter'],
            'Radiator Bocor' => ['Generator Radiator'],
            'Aftercooler Tidak Berfungsi' => ['Compressor Aftercooler'],
        ];

        // Group machines by plant
        $machinesByPlant = $utilityMachines->groupBy('plant_id');

        $totalDowntimes = 0;
        $downtimes = [];

        // Period: January 2025 to November 21, 2025
        $startDate = Carbon::create(2025, 1, 1);
        $endDate = Carbon::create(2025, 11, 21);

        // Generate 25 downtimes per month per plant
        $months = [];
        $current = $startDate->copy();
        while ($current->lte($endDate)) {
            $monthKey = $current->format('Y-m');
            if (!isset($months[$monthKey])) {
                $months[$monthKey] = [
                    'start' => $current->copy()->startOfMonth(),
                    'end' => $current->copy()->endOfMonth()->min($endDate),
                ];
            }
            $current->addMonth();
        }

        foreach ($machinesByPlant as $plantId => $plantMachines) {
            $this->command->info("Processing Plant ID: {$plantId} with {$plantMachines->count()} machines");

            foreach ($months as $monthKey => $monthRange) {
                $monthStart = $monthRange['start'];
                $monthEnd = $monthRange['end'];
                
                // Generate 25 downtimes for this plant in this month
                $downtimesPerMonth = 25;
                
                // Get all weekdays in this month (exclude weekends)
                $weekdays = [];
                $currentDay = $monthStart->copy();
                while ($currentDay->lte($monthEnd)) {
                    // Skip weekends (Saturday = 6, Sunday = 0)
                    if ($currentDay->dayOfWeek != 6 && $currentDay->dayOfWeek != 0) {
                        $weekdays[] = $currentDay->copy();
                    }
                    $currentDay->addDay();
                }

                if (empty($weekdays)) {
                    $this->command->warn("No weekdays found for {$monthKey}, skipping...");
                    continue;
                }

                // Track used dates per machine to avoid too many downtimes on same day
                $usedDates = [];

                for ($i = 0; $i < $downtimesPerMonth; $i++) {
                    // Random machine from this plant
                    $machine = $plantMachines->random();
                    $machineId = $machine->id;

                    // Find a weekday that hasn't been used too many times for this machine
                    $attempts = 0;
                    $date = null;
                    do {
                        $randomDate = $weekdays[array_rand($weekdays)];
                        $dateKey = $randomDate->format('Y-m-d');
                        
                        // Check if this date has been used too many times for this machine (max 2 per day per machine)
                        $dateMachineKey = "{$dateKey}_{$machineId}";
                        $usageCount = isset($usedDates[$dateMachineKey]) ? $usedDates[$dateMachineKey] : 0;
                        
                        if ($usageCount < 2) {
                            $date = $randomDate->copy();
                            $usedDates[$dateMachineKey] = $usageCount + 1;
                            break;
                        }
                        
                        $attempts++;
                    } while ($attempts < 100);

                    if (!$date) {
                        // Fallback: use first available weekday
                        $date = $weekdays[0]->copy();
                    }


                    // Get machine type name
                    $machineTypeName = $machine->machineType->name ?? 'Air Compressor';
                    $availableProblems = $problemMachineTypeMap[$machineTypeName] ?? $problemMachineTypeMap['Air Compressor'];
                    
                    // Random problem for this machine type
                    $problemName = $availableProblems[array_rand($availableProblems)];
                    $problem = $allProblems->get($problemName);

                    if (!$problem) {
                        $problem = $allProblems->random(); // Fallback
                    }

                    // Determine group based on machine type
                    $group = $defaultGroup;
                    if ($machineTypeName == 'Air Compressor' && $compressingGroup) {
                        $group = $compressingGroup;
                    } elseif ($machineTypeName == 'Blower Exhaust' && $blowerGroup) {
                        $group = $blowerGroup;
                    } elseif ($machineTypeName == 'Boiler' && $boilerGroup) {
                        $group = $boilerGroup;
                    } elseif ($machineTypeName == 'Generator Set' && $gensetGroup) {
                        $group = $gensetGroup;
                    }

                    // Random time during working hours (7 AM - 5 PM)
                    $hour = rand(7, 16);
                    $minute = rand(0, 59);
                    $stopProduction = $date->copy()->setTime($hour, $minute);

                    // Response time: 5-30 minutes after stop
                    $responseMinutes = rand(5, 30);
                    $responMechanic = $stopProduction->copy()->addMinutes($responseMinutes);

                    // Duration: 15 minutes to 4 hours
                    $durationMinutes = rand(15, 240);
                    $startProduction = $responMechanic->copy()->addMinutes($durationMinutes);

                    // Random users
                    $mekanik = $mechanics->random();
                    $leader = $leaders->random();
                    $coord = $coords->random();

                    // Random reason and action
                    $reason = $reasons->random();
                    $action = $actions->random();

                    // Determine if uses sparepart (45% chance)
                    $usesSparepart = rand(1, 100) <= 45;
                    $selectedPartNames = [];
                    $repairCost = 0;

                    if ($usesSparepart && $parts->isNotEmpty()) {
                        // If problem has mapped parts, use them
                        if (isset($problemPartMap[$problemName]) && !empty($problemPartMap[$problemName])) {
                            $availablePartNames = $problemPartMap[$problemName];
                        } else {
                            $availablePartNames = $parts->pluck('name')->toArray();
                        }

                        if (!empty($availablePartNames)) {
                            // Distribution: 50% 1 part, 30% 2 parts, 20% 3 parts
                            $randomDist = rand(1, 100);
                            $numParts = $randomDist <= 50 ? 1 : ($randomDist <= 80 ? 2 : min(3, count($availablePartNames)));

                            $shuffledParts = $availablePartNames;
                            shuffle($shuffledParts);
                            $selectedPartNames = array_slice($shuffledParts, 0, $numParts);

                            foreach ($selectedPartNames as $partName) {
                                $part = $parts->firstWhere('name', $partName);
                                if ($part && $part->price) {
                                    $maxQuantity = $numParts == 1 ? 3 : 2;
                                    $quantity = rand(1, $maxQuantity);
                                    $repairCost += $part->price * $quantity;
                                }
                            }
                        }
                    }

                    // If no sparepart or cost is 0, add manual repair cost
                    if ($repairCost == 0) {
                        $repairCost = rand(50000, 500000);
                    } else {
                        $serviceCost = $repairCost * (rand(20, 30) / 100);
                        $repairCost += $serviceCost;
                    }

                    $downtimes[] = [
                        'machine_id' => $machine->id,
                        'date' => $date->format('Y-m-d'),
                        'stopProduction' => $stopProduction,
                        'responMechanic' => $responMechanic,
                        'startProduction' => $startProduction,
                        'duration' => $durationMinutes,
                        'standard_time' => null,
                        'problem_id' => $problem->id,
                        'problem_mm_id' => null,
                        'reason_id' => $reason->id,
                        'action_id' => $action->id,
                        'group_id' => $group->id,
                        'part' => !empty($selectedPartNames) ? implode(', ', $selectedPartNames) : null,
                        'mekanik_id' => $mekanik->id,
                        'leader_id' => $leader->id,
                        'coord_id' => $coord->id,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];

                    $totalDowntimes++;
                }
            }
        }

        $this->command->info("Generated {$totalDowntimes} downtime records");

        // Insert in batches
        $this->command->info("Inserting downtimes in batches...");
        $batchCount = 0;
        foreach (array_chunk($downtimes, 100) as $chunk) {
            $batchCount++;
            foreach ($chunk as $downtimeData) {
                Downtime::create($downtimeData);
            }
            if ($batchCount % 10 == 0) {
                $this->command->info("Inserted batch {$batchCount}...");
            }
        }

        $this->command->info("Downtime seeding completed! Total: {$totalDowntimes} records");
    }
}

