<?php

namespace Database\Seeders;

use App\Models\PreventiveMaintenanceSchedule;
use App\Models\PreventiveMaintenanceExecution;
use App\Models\Machine;
use App\Models\MaintenancePoint;
use App\Models\User;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class PreventiveMaintenanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get all machines
        $machines = Machine::with('machineType')->get();

        if ($machines->isEmpty()) {
            $this->command->warn('No machines found. Please run MachineSeeder first.');
            return;
        }

        // Get users for assignment (mechanics, team leaders, group leaders, coordinators)
        $mechanics = User::where('role', 'mekanik')->get();
        $teamLeaders = User::where('role', 'team_leader')->get();
        $groupLeaders = User::where('role', 'group_leader')->get();
        $coordinators = User::where('role', 'coordinator')->get();

        $allUsers = $mechanics->merge($teamLeaders)->merge($groupLeaders)->merge($coordinators);

        if ($allUsers->isEmpty()) {
            $this->command->warn('No users found. Please run UserSeeder first.');
            return;
        }

        $schedulesCreated = 0;
        $executionsCreated = 0;
        $currentYear = 2025;

        foreach ($machines as $machine) {
            if (!$machine->machineType) {
                continue;
            }

            // Get maintenance points for this machine type (preventive category)
            $maintenancePoints = MaintenancePoint::where('machine_type_id', $machine->machine_type_id)
                ->where('category', 'preventive')
                ->orderBy('sequence', 'asc')
                ->get();

            if ($maintenancePoints->isEmpty()) {
                continue;
            }

            // Assign a random user to this machine's schedules
            $assignedUser = $allUsers->random();

            // Create schedules for each maintenance point
            foreach ($maintenancePoints as $point) {
                $frequencyType = $point->frequency_type ?? 'monthly';
                $frequencyValue = $point->frequency_value ?? 1;

                // Start from January 1, 2025
                $startDate = Carbon::create($currentYear, 1, 1);
                $endDate = Carbon::create($currentYear, 12, 31);

                // Calculate preferred time (random between 08:00 - 16:00)
                $preferredHour = rand(8, 15);
                $preferredMinute = rand(0, 59);
                $preferredTime = Carbon::createFromTime($preferredHour, $preferredMinute);

                // Estimated duration (30-120 minutes)
                $estimatedDuration = rand(30, 120);

                $currentScheduleDate = clone $startDate;

                // Generate schedules until end of year
                while ($currentScheduleDate->lte($endDate)) {
                    // Create schedule
                    $schedule = PreventiveMaintenanceSchedule::firstOrCreate(
                        [
                            'machine_id' => $machine->id,
                            'maintenance_point_id' => $point->id,
                            'start_date' => $currentScheduleDate->format('Y-m-d'),
                        ],
                        [
                            'title' => $point->name,
                            'description' => $point->instruction ?? 'Preventive maintenance untuk ' . $point->name,
                            'frequency_type' => $frequencyType,
                            'frequency_value' => $frequencyValue,
                            'end_date' => $endDate->format('Y-m-d'),
                            'preferred_time' => $preferredTime->format('H:i:s'),
                            'estimated_duration' => $estimatedDuration,
                            'status' => 'active',
                            'assigned_to' => $assignedUser->id,
                            'notes' => null,
                        ]
                    );

                    $schedulesCreated++;

                    // Create execution for some schedules (70% completed, 15% in_progress, 10% pending, 5% skipped)
                    $executionChance = rand(1, 100);
                    $executionStatus = null;

                    if ($executionChance <= 70) {
                        // Completed
                        $executionStatus = 'completed';
                    } elseif ($executionChance <= 85) {
                        // In Progress
                        $executionStatus = 'in_progress';
                    } elseif ($executionChance <= 95) {
                        // Pending
                        $executionStatus = 'pending';
                    } else {
                        // Skipped
                        $executionStatus = 'skipped';
                    }

                    // Only create execution if status is not null and schedule date is in the past or today
                    if ($executionStatus && $currentScheduleDate->lte(now())) {
                        $performedBy = $allUsers->random();

                        $actualStartTime = null;
                        $actualEndTime = null;

                        if ($executionStatus == 'completed') {
                            // Actual start time: same day, between preferred time and preferred time + 2 hours
                            $actualStartTime = $currentScheduleDate->copy()
                                ->setTime($preferredHour, rand(0, 59))
                                ->addHours(rand(0, 2));

                            // Actual end time: start time + estimated duration + some variance
                            $actualEndTime = $actualStartTime->copy()
                                ->addMinutes($estimatedDuration + rand(-15, 30));
                        } elseif ($executionStatus == 'in_progress') {
                            // Actual start time: same day, between preferred time and preferred time + 2 hours
                            $actualStartTime = $currentScheduleDate->copy()
                                ->setTime($preferredHour, rand(0, 59))
                                ->addHours(rand(0, 2));

                            // No end time yet (in progress)
                            $actualEndTime = null;
                        }

                        // Findings and actions (in Indonesian)
                        $findingsOptions = [
                            'Tidak ada masalah ditemukan',
                            'Ditemukan sedikit kotoran pada komponen',
                            'Beberapa bagian perlu perawatan lebih lanjut',
                            'Kondisi mesin normal',
                            'Ditemukan keausan ringan pada beberapa bagian',
                            'Semua komponen dalam kondisi baik',
                        ];

                        $actionsOptions = [
                            'Pembersihan rutin dilakukan',
                            'Pelumasan komponen dilakukan',
                            'Pemeriksaan visual selesai',
                            'Tidak ada tindakan yang diperlukan',
                            'Pembersihan dan pelumasan dilakukan',
                            'Semua komponen telah diperiksa dan dibersihkan',
                        ];

                        $findings = $executionStatus == 'completed' ? $findingsOptions[array_rand($findingsOptions)] : null;
                        $actionsTaken = $executionStatus == 'completed' ? $actionsOptions[array_rand($actionsOptions)] : null;

                        // Cost (random between 50,000 - 500,000)
                        $cost = $executionStatus == 'completed' ? rand(50000, 500000) : null;

                        // Checklist
                        $checklist = [
                            [
                                'item' => $point->name,
                                'checked' => $executionStatus == 'completed',
                                'notes' => $executionStatus == 'completed' ? 'Selesai dilakukan' : null,
                            ],
                        ];

                        PreventiveMaintenanceExecution::firstOrCreate(
                            [
                                'schedule_id' => $schedule->id,
                                'scheduled_date' => $currentScheduleDate->format('Y-m-d'),
                            ],
                            [
                                'actual_start_time' => $actualStartTime ? $actualStartTime->format('Y-m-d H:i:s') : null,
                                'actual_end_time' => $actualEndTime ? $actualEndTime->format('Y-m-d H:i:s') : null,
                                'status' => $executionStatus,
                                'performed_by' => $performedBy->id,
                                'findings' => $findings,
                                'actions_taken' => $actionsTaken,
                                'notes' => $executionStatus == 'completed' ? 'Maintenance selesai dilakukan sesuai jadwal' : null,
                                'checklist' => $checklist,
                                'cost' => $cost,
                                'photo_before' => null,
                                'photo_after' => null,
                            ]
                        );

                        $executionsCreated++;
                    }

                    // Calculate next schedule date based on frequency
                    $currentScheduleDate = $this->calculateNextDate($currentScheduleDate, $frequencyType, $frequencyValue);

                    // Safety check to prevent infinite loop
                    if ($schedulesCreated > 5000) {
                        break 2; // Break both loops
                    }
                }
            }
        }

        $this->command->info("Preventive Maintenance Seeder completed:");
        $this->command->info("- Schedules created: {$schedulesCreated}");
        $this->command->info("- Executions created: {$executionsCreated}");
    }

    private function calculateNextDate($currentDate, $frequencyType, $frequencyValue = 1)
    {
        $next = clone $currentDate;

        switch ($frequencyType) {
            case 'daily':
                $next->addDays($frequencyValue);
                break;
            case 'weekly':
                $next->addWeeks($frequencyValue);
                break;
            case 'monthly':
                $next->addMonths($frequencyValue);
                break;
            case 'quarterly':
                $next->addMonths($frequencyValue * 3);
                break;
            case 'yearly':
                $next->addYears($frequencyValue);
                break;
            default:
                // Default to monthly
                $next->addMonths($frequencyValue);
                break;
        }

        return $next;
    }
}
