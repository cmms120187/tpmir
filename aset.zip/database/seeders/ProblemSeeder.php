<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Problem;
use App\Models\System;

class ProblemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get systems
        $mechanical = System::where('nama_sistem', 'Mechanical')->first();
        $electrical = System::where('nama_sistem', 'Electrical')->first();
        $pneumatic = System::where('nama_sistem', 'Pneumatic')->first();
        $cooling = System::where('nama_sistem', 'Cooling')->first();
        $heating = System::where('nama_sistem', 'Heating')->first();
        $electronic = System::where('nama_sistem', 'Electronic')->first();
        $lubrication = System::where('nama_sistem', 'Lubrication')->first();

        $problems = [
            // Masalah Air Compressor - bisa multiple systems
            ['name' => 'Kompresor Overheating', 'systems' => [$mechanical?->id, $cooling?->id], 'problem_mm' => null],
            ['name' => 'Kebocoran Udara di Sistem', 'systems' => [$pneumatic?->id], 'problem_mm' => null],
            ['name' => 'Motor Kompresor Rusak', 'systems' => [$electrical?->id], 'problem_mm' => null],
            ['name' => 'Filter Oli Kompresor Tersumbat', 'systems' => [$mechanical?->id, $lubrication?->id], 'problem_mm' => null],
            ['name' => 'Pressure Switch Bermasalah', 'systems' => [$electrical?->id, $electronic?->id], 'problem_mm' => null],
            ['name' => 'Belt Slippage', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Aftercooler Tidak Berfungsi', 'systems' => [$cooling?->id], 'problem_mm' => null],

            // Masalah Blower Exhaust
            ['name' => 'Impeller Blower Rusak', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Bearing Motor Rusak', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'V-Belt Putus', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Motor Blower Overload', 'systems' => [$electrical?->id], 'problem_mm' => null],
            ['name' => 'Aliran Udara Tidak Cukup', 'systems' => [$mechanical?->id, $pneumatic?->id], 'problem_mm' => null],

            // Masalah Boiler
            ['name' => 'Level Air Boiler Rendah', 'systems' => [$heating?->id], 'problem_mm' => null],
            ['name' => 'Nozzle Burner Tersumbat', 'systems' => [$heating?->id], 'problem_mm' => null],
            ['name' => 'Temperature Controller Rusak', 'systems' => [$electronic?->id], 'problem_mm' => null],
            ['name' => 'Safety Valve Bocor', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Heating Element Terbakar', 'systems' => [$electrical?->id, $heating?->id], 'problem_mm' => null],
            ['name' => 'Pressure Gauge Rusak', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Thermocouple Bermasalah', 'systems' => [$electronic?->id], 'problem_mm' => null],
            ['name' => 'Insulasi Boiler Rusak', 'systems' => [$heating?->id], 'problem_mm' => null],

            // Masalah Generator Set
            ['name' => 'Mesin Generator Overheating', 'systems' => [$mechanical?->id, $cooling?->id], 'problem_mm' => null],
            ['name' => 'Filter Bahan Bakar Tersumbat', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Busi Kotor', 'systems' => [$mechanical?->id], 'problem_mm' => null],
            ['name' => 'Filter Oli Generator Tersumbat', 'systems' => [$lubrication?->id], 'problem_mm' => null],
            ['name' => 'Radiator Bocor', 'systems' => [$cooling?->id], 'problem_mm' => null],
            ['name' => 'Baterai Mati', 'systems' => [$electrical?->id], 'problem_mm' => null],
            ['name' => 'Alternator Rusak', 'systems' => [$electrical?->id], 'problem_mm' => null],
            ['name' => 'Fluktuasi Tegangan Generator', 'systems' => [$electrical?->id, $electronic?->id], 'problem_mm' => null],
        ];

        foreach ($problems as $problemData) {
            $systems = $problemData['systems'];
            unset($problemData['systems']);
            
            // Filter out null values from systems array
            $systems = array_filter($systems, fn($id) => $id !== null);
            
            // Use updateOrCreate to ensure systems are always synced
            $problem = Problem::updateOrCreate(
                ['name' => $problemData['name']],
                $problemData
            );
            
            // Always sync systems, even if empty (to clear old associations)
            $problem->systems()->sync($systems);
        }
    }
}
