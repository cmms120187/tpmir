<?php

namespace Database\Seeders;

use App\Models\WorkOrder;
use App\Models\Machine;
use App\Models\User;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class WorkOrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get machines (prioritize utility machines)
        $machines = Machine::whereHas('machineType', function($q) {
            $q->whereIn('name', ['Air Compressor', 'Blower Exhaust', 'Boiler', 'Generator Set']);
        })->get();

        if ($machines->isEmpty()) {
            // Fallback to all machines if no utility machines found
            $machines = Machine::all();
        }

        // Get users
        $users = User::all();
        $mechanics = User::whereIn('name', ['Ahmad Rizki', 'Budi Santoso', 'Cahyo Wibowo'])->get();
        $leaders = User::whereIn('name', ['Dedi Kurniawan', 'Eko Prasetyo'])->get();
        $coordinators = User::whereIn('name', ['Fajar Hidayat', 'Gunawan Sari'])->get();
        $admin = User::where('email', 'wahid@tpmcmms.id')->first();

        if ($users->isEmpty() || $machines->isEmpty()) {
            $this->command->warn('No users or machines found. Please run UserSeeder and MachineSeeder first.');
            return;
        }

        $descriptions = [
            'Routine maintenance check',
            'Replace worn-out parts',
            'Oil change and filter replacement',
            'Calibration and adjustment',
            'Electrical system inspection',
            'Mechanical component repair',
            'Preventive maintenance schedule',
            'Emergency repair',
            'Performance optimization',
            'Safety inspection',
            'Cleaning and lubrication',
            'Belt replacement',
            'Bearing replacement',
            'Valve repair',
            'Sensor calibration',
            'Control panel maintenance',
            'Cooling system service',
            'Pneumatic system check',
            'Hydraulic system maintenance',
            'Annual overhaul',
        ];

        $problemDescriptions = [
            'Abnormal noise detected during operation',
            'Reduced efficiency and performance',
            'Oil leak detected',
            'Temperature reading above normal',
            'Pressure drop observed',
            'Vibration issues',
            'Electrical fault',
            'Component wear beyond tolerance',
            'Scheduled maintenance due',
            'Preventive maintenance required',
            'Performance degradation',
            'Safety concern identified',
            'Control system malfunction',
            'Cooling system not working properly',
            'Lubrication system issue',
        ];

        $solutions = [
            'Replaced worn components and adjusted settings',
            'Cleaned and lubricated all moving parts',
            'Fixed electrical connection and tested system',
            'Replaced faulty sensor and recalibrated',
            'Performed complete overhaul and testing',
            'Adjusted parameters and optimized performance',
            'Replaced oil and filters, system running smoothly',
            'Fixed leak and replaced damaged parts',
            'Calibrated all sensors and control systems',
            'Completed preventive maintenance checklist',
        ];

        $notes = [
            'Regular maintenance completed successfully',
            'All systems checked and functioning properly',
            'Recommend follow-up inspection in 3 months',
            'Parts replaced from inventory',
            'No issues found during inspection',
            'System performance improved after maintenance',
            'All safety checks passed',
            'Documentation updated',
        ];

        $statuses = ['pending', 'in_progress', 'completed', 'cancelled'];
        $priorities = ['low', 'medium', 'high', 'urgent'];

        $startDate = Carbon::parse('2025-01-01');
        $endDate = Carbon::parse('2025-12-31');

        // Generate work orders for each month in 2025
        for ($month = 1; $month <= 12; $month++) {
            $daysInMonth = Carbon::create(2025, $month, 1)->daysInMonth;
            $workOrdersPerMonth = rand(15, 25); // 15-25 work orders per month

            for ($i = 0; $i < $workOrdersPerMonth; $i++) {
                $orderDate = Carbon::create(2025, $month, rand(1, $daysInMonth));
                $status = $statuses[array_rand($statuses)];
                $priority = $priorities[array_rand($priorities)];

                $machine = $machines->random();
                $assignedTo = null;
                $createdBy = $admin ? $admin->id : $users->random()->id;

                // Assign to mechanic/leader/coordinator based on priority
                if ($priority == 'urgent' || $priority == 'high') {
                    if ($coordinators->isNotEmpty() && rand(0, 1)) {
                        $assignedTo = $coordinators->random()->id;
                    } elseif ($leaders->isNotEmpty() && rand(0, 1)) {
                        $assignedTo = $leaders->random()->id;
                    } elseif ($mechanics->isNotEmpty()) {
                        $assignedTo = $mechanics->random()->id;
                    }
                } else {
                    if ($mechanics->isNotEmpty() && rand(0, 1)) {
                        $assignedTo = $mechanics->random()->id;
                    } elseif ($leaders->isNotEmpty() && rand(0, 1)) {
                        $assignedTo = $leaders->random()->id;
                    }
                }

                // Generate WO Number - check existing work orders for this date
                $datePrefix = 'WO-' . $orderDate->format('Ymd') . '-';
                $lastWo = WorkOrder::where('wo_number', 'like', $datePrefix . '%')
                    ->orderBy('wo_number', 'desc')
                    ->first();

                if ($lastWo) {
                    $lastNumber = (int) str_replace($datePrefix, '', $lastWo->wo_number);
                    $woCounter = $lastNumber + 1;
                } else {
                    $woCounter = 1;
                }

                $woNumber = $datePrefix . str_pad($woCounter, 4, '0', STR_PAD_LEFT);

                // Check if this WO number already exists
                if (WorkOrder::where('wo_number', $woNumber)->exists()) {
                    // If exists, skip this iteration or generate a new unique number
                    continue;
                }

                // Calculate dates based on status
                $dueDate = $orderDate->copy()->addDays(rand(1, 7));
                $startedAt = null;
                $completedAt = null;

                if ($status == 'in_progress' || $status == 'completed') {
                    $startedAt = $orderDate->copy()->addHours(rand(1, 24));
                }

                if ($status == 'completed') {
                    $completedAt = $startedAt ? $startedAt->copy()->addHours(rand(2, 48)) : $orderDate->copy()->addDays(rand(1, 5));
                }

                // Calculate costs and duration
                $estimatedCost = rand(500000, 5000000); // Rp 500k - 5M
                $estimatedDuration = rand(60, 480); // 1-8 hours in minutes
                $actualCost = null;
                $actualDuration = null;

                if ($status == 'completed') {
                    // Actual cost can be slightly different from estimated
                    $actualCost = $estimatedCost + rand(-200000, 500000);
                    $actualDuration = $estimatedDuration + rand(-30, 60);
                }

                // Use firstOrCreate to avoid duplicates
                $workOrder = WorkOrder::firstOrCreate(
                    ['wo_number' => $woNumber],
                    [
                        'order_date' => $orderDate,
                        'status' => $status,
                        'priority' => $priority,
                        'machine_id' => $machine->id,
                        'description' => $descriptions[array_rand($descriptions)],
                        'problem_description' => rand(0, 1) ? $problemDescriptions[array_rand($problemDescriptions)] : null,
                        'assigned_to' => $assignedTo,
                        'created_by' => $createdBy,
                        'due_date' => $dueDate,
                        'started_at' => $startedAt,
                        'completed_at' => $completedAt,
                        'notes' => rand(0, 1) ? $notes[array_rand($notes)] : null,
                        'solution' => ($status == 'completed') ? $solutions[array_rand($solutions)] : null,
                        'estimated_cost' => $estimatedCost,
                        'actual_cost' => $actualCost,
                        'estimated_duration_minutes' => $estimatedDuration,
                        'actual_duration_minutes' => $actualDuration,
                    ]
                );
            }
        }

        $this->command->info('Work Orders seeded successfully!');
    }
}
