<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Model;
use App\Models\Brand;
use App\Models\MachineType;
use Illuminate\Support\Facades\DB;

class ModelFromDowntimeErpSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $csvPath = base_path('downtime2024revisi.csv');
        
        if (!file_exists($csvPath)) {
            $this->command->error('CSV file not found: ' . $csvPath);
            return;
        }

        $handle = fopen($csvPath, 'r');
        if (!$handle) {
            $this->command->error('Could not open CSV file');
            return;
        }

        // Read header
        $header = fgetcsv($handle, 0, "\t");
        
        // Normalize header
        $header = array_map(function($h) {
            $h = trim($h);
            if ($h === 'Standar Time') {
                return 'Standar_Time';
            }
            return $h;
        }, $header);

        // Verify required columns exist
        if (!in_array('modelMachine', $header) || !in_array('brandMachine', $header) || !in_array('typeMachine', $header)) {
            $this->command->error('Required columns not found in CSV');
            fclose($handle);
            return;
        }

        // Pre-load all existing brands and machine types for performance
        $brandsCache = Brand::all()->keyBy('name');
        $machineTypesCache = MachineType::all()->keyBy('name');
        
        // Pre-load all existing models by name (for update)
        $existingModelsByName = Model::all()->groupBy('name');
        
        // Store model name to most common brand_id and type_id mapping from CSV
        $modelToBrandType = [];
        $rowNumber = 0;

        $this->command->info('Reading CSV file to build model mapping...');

        // First pass: Build mapping of model name to most common brand_id and type_id
        while (($row = fgetcsv($handle, 0, "\t")) !== false) {
            $rowNumber++;
            
            // Skip if row count doesn't match header count
            if (count($row) !== count($header)) {
                continue;
            }

            $data = array_combine($header, $row);
            
            $modelMachine = trim($data['modelMachine'] ?? '');
            $brandMachine = trim($data['brandMachine'] ?? '');
            $typeMachine = trim($data['typeMachine'] ?? '');

            // Skip if any field is empty
            if (empty($modelMachine) || empty($brandMachine) || empty($typeMachine)) {
                continue;
            }

            // Get or create Brand
            if (!$brandsCache->has($brandMachine)) {
                $brand = Brand::firstOrCreate(
                    ['name' => $brandMachine],
                    ['name' => $brandMachine]
                );
                $brandsCache->put($brandMachine, $brand);
            } else {
                $brand = $brandsCache->get($brandMachine);
            }

            // Get or create MachineType
            if (!$machineTypesCache->has($typeMachine)) {
                $machineType = MachineType::firstOrCreate(
                    ['name' => $typeMachine],
                    ['name' => $typeMachine]
                );
                $machineTypesCache->put($typeMachine, $machineType);
            } else {
                $machineType = $machineTypesCache->get($typeMachine);
            }

            // Count occurrences of each model + brand + type combination
            $key = $modelMachine . '|' . $brand->id . '|' . $machineType->id;
            if (!isset($modelToBrandType[$modelMachine])) {
                $modelToBrandType[$modelMachine] = [];
            }
            if (!isset($modelToBrandType[$modelMachine][$key])) {
                $modelToBrandType[$modelMachine][$key] = 0;
            }
            $modelToBrandType[$modelMachine][$key]++;
        }

        fclose($handle);

        // For each model, find the most common brand_id and type_id combination
        $modelUpdates = [];
        foreach ($modelToBrandType as $modelName => $combinations) {
            // Find the combination with highest count
            arsort($combinations);
            $mostCommonKey = key($combinations);
            list($_, $brandId, $typeId) = explode('|', $mostCommonKey);
            
            $modelUpdates[$modelName] = [
                'brand_id' => (int)$brandId,
                'type_id' => (int)$typeId,
            ];
        }

        $this->command->info('Found ' . count($modelUpdates) . ' unique models in CSV');
        $this->command->info('Updating existing models...');

        // Update existing models
        $updatedCount = 0;
        $createdCount = 0;
        
        foreach ($modelUpdates as $modelName => $data) {
            // Find all models with this name
            $models = Model::where('name', $modelName)->get();
            
            if ($models->isEmpty()) {
                // Model doesn't exist, create new
                try {
                    Model::create([
                        'name' => $modelName,
                        'brand_id' => $data['brand_id'],
                        'type_id' => $data['type_id'],
                    ]);
                    $createdCount++;
                } catch (\Exception $e) {
                    $this->command->warn('Error creating model: ' . $modelName . ' - ' . $e->getMessage());
                }
            } else {
                // Update all models with this name
                foreach ($models as $model) {
                    // Only update if brand_id or type_id is null or different
                    if (is_null($model->brand_id) || is_null($model->type_id) || 
                        $model->brand_id != $data['brand_id'] || $model->type_id != $data['type_id']) {
                        try {
                            $model->brand_id = $data['brand_id'];
                            $model->type_id = $data['type_id'];
                            $model->save();
                            $updatedCount++;
                        } catch (\Exception $e) {
                            $this->command->warn('Error updating model: ' . $modelName . ' (ID: ' . $model->id . ') - ' . $e->getMessage());
                        }
                    }
                }
            }
            
            // Progress indicator
            if (($updatedCount + $createdCount) % 50 == 0) {
                $this->command->info("Processed " . ($updatedCount + $createdCount) . " models... (Updated: $updatedCount, Created: $createdCount)");
            }
        }

        $this->command->info("=== Seeding Complete ===");
        $this->command->info("Total rows in CSV: $rowNumber");
        $this->command->info("Unique models found: " . count($modelUpdates));
        $this->command->info("Created: $createdCount new models");
        $this->command->info("Updated: $updatedCount existing models");
        $this->command->info("Total Models in database: " . Model::count());
        $this->command->info("Models without brand_id or type_id: " . Model::whereNull('brand_id')->orWhereNull('type_id')->count());
        $this->command->info("Total Brands in database: " . Brand::count());
        $this->command->info("Total MachineTypes in database: " . MachineType::count());
    }
}
