<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Reason;

class ReasonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $reasons = [
            'Usia Komponen',
            'Kurang Maintenance',
            'Operasi Tidak Sesuai Prosedur',
            'Kualitas Sparepart Buruk',
            'Kondisi Lingkungan',
            'Wear and Tear Normal',
            'Kesalahan Instalasi',
            'Overload',
            'Kontaminasi',
            'Korosi',
            'Vibrasi Berlebihan',
            'Kurang Pelumasan',
            'Suhu Berlebihan',
            'Tekanan Berlebihan',
            'Kesalahan Operator',
        ];

        foreach ($reasons as $reason) {
            Reason::firstOrCreate(['name' => $reason]);
        }
    }
}
