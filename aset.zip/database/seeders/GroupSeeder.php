<?php

namespace Database\Seeders;

use App\Models\Group;
use App\Models\System;
use Illuminate\Database\Seeder;

class GroupSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get Systems
        $mechanical = System::where('nama_sistem', 'Mechanical')->first();
        $electrical = System::where('nama_sistem', 'Electrical')->first();
        $pneumatic = System::where('nama_sistem', 'Pneumatic')->first();
        $cooling = System::where('nama_sistem', 'Cooling')->first();
        $heating = System::where('nama_sistem', 'Heating')->first();
        $lubrication = System::where('nama_sistem', 'Lubrication')->first();
        $hydraulic = System::where('nama_sistem', 'Hydraulic')->first();
        $electronic = System::where('nama_sistem', 'Electronic')->first();

        // Compressing Group - Air Compressor related
        $compressing = Group::firstOrCreate(['name' => 'Compressing']);
        $compressingSystems = [];
        if ($mechanical) $compressingSystems[] = $mechanical->id;
        if ($electrical) $compressingSystems[] = $electrical->id;
        if ($pneumatic) $compressingSystems[] = $pneumatic->id;
        if ($cooling) $compressingSystems[] = $cooling->id;
        if ($compressingSystems) {
            $compressing->systems()->sync($compressingSystems);
            $this->command->info("Created/Updated Group: Compressing with " . count($compressingSystems) . " systems");
        }

        // Blower Group - Blower Exhaust related
        $blower = Group::firstOrCreate(['name' => 'Blower']);
        $blowerSystems = [];
        if ($mechanical) $blowerSystems[] = $mechanical->id;
        if ($electrical) $blowerSystems[] = $electrical->id;
        if ($cooling) $blowerSystems[] = $cooling->id;
        if ($blowerSystems) {
            $blower->systems()->sync($blowerSystems);
            $this->command->info("Created/Updated Group: Blower with " . count($blowerSystems) . " systems");
        }

        // Boiler Group - Boiler related
        $boiler = Group::firstOrCreate(['name' => 'Boiler']);
        $boilerSystems = [];
        if ($mechanical) $boilerSystems[] = $mechanical->id;
        if ($electrical) $boilerSystems[] = $electrical->id;
        if ($heating) $boilerSystems[] = $heating->id;
        if ($boilerSystems) {
            $boiler->systems()->sync($boilerSystems);
            $this->command->info("Created/Updated Group: Boiler with " . count($boilerSystems) . " systems");
        }

        // Genset Group - Generator Set related
        $genset = Group::firstOrCreate(['name' => 'Genset']);
        $gensetSystems = [];
        if ($mechanical) $gensetSystems[] = $mechanical->id;
        if ($electrical) $gensetSystems[] = $electrical->id;
        if ($lubrication) $gensetSystems[] = $lubrication->id;
        if ($gensetSystems) {
            $genset->systems()->sync($gensetSystems);
            $this->command->info("Created/Updated Group: Genset with " . count($gensetSystems) . " systems");
        }

        // Production Group - Production machines related
        $production = Group::firstOrCreate(['name' => 'Production']);
        $productionSystems = [];
        if ($mechanical) $productionSystems[] = $mechanical->id;
        if ($electrical) $productionSystems[] = $electrical->id;
        if ($pneumatic) $productionSystems[] = $pneumatic->id;
        if ($electronic) $productionSystems[] = $electronic->id;
        if ($productionSystems) {
            $production->systems()->sync($productionSystems);
            $this->command->info("Created/Updated Group: Production with " . count($productionSystems) . " systems");
        }

        // Quality Control Group - Quality Control machines related
        $qualityControl = Group::firstOrCreate(['name' => 'Quality Control']);
        $qualityControlSystems = [];
        if ($electronic) $qualityControlSystems[] = $electronic->id;
        if ($qualityControlSystems) {
            $qualityControl->systems()->sync($qualityControlSystems);
            $this->command->info("Created/Updated Group: Quality Control with " . count($qualityControlSystems) . " systems");
        }

        // Remove Maintenance group if it exists (cleanup - not needed for utility groups)
        $maintenanceGroup = Group::where('name', 'Maintenance')->first();
        if ($maintenanceGroup) {
            $maintenanceGroup->systems()->detach();
            $maintenanceGroup->delete();
            $this->command->info("Removed Maintenance group (not needed for utility groups)");
        }

        $this->command->info("\nGroup seeding completed!");
        $this->command->info("Total groups created: " . Group::count());
    }
}

