<?php

namespace Database\Seeders;

use App\Models\Brand;
use App\Models\MachineType;
use App\Models\Model;
use Illuminate\Database\Seeder;

class ModelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get Brands
        $atlasCopco = Brand::where('name', 'Atlas Copco')->first();
        $ingersollRand = Brand::where('name', 'Ingersoll Rand')->first();
        $gardnerDenver = Brand::where('name', 'Gardner Denver')->first();
        $kaeser = Brand::where('name', 'Kaeser')->first();
        $bosch = Brand::where('name', 'Bosch')->first();
        $cleaverBrooks = Brand::where('name', 'Cleaver-Brooks')->first();
        $cummins = Brand::where('name', 'Cummins')->first();
        $perkins = Brand::where('name', 'Perkins')->first();
        $hobart = Brand::where('name', 'Hobart')->first();
        $krones = Brand::where('name', 'Krones')->first();
        $interroll = Brand::where('name', 'Interroll')->first();
        $weber = Brand::where('name', 'Weber')->first();
        $mettlerToledo = Brand::where('name', 'Mettler Toledo')->first();
        $hannaInstruments = Brand::where('name', 'Hanna Instruments')->first();
        $shimadzu = Brand::where('name', 'Shimadzu')->first();

        // Get Machine Types
        $airCompressor = MachineType::where('name', 'Air Compressor')->first();
        $blowerExhaust = MachineType::where('name', 'Blower Exhaust')->first();
        $boiler = MachineType::where('name', 'Boiler')->first();
        $generatorSet = MachineType::where('name', 'Generator Set')->first();
        $mixingMachine = MachineType::where('name', 'Mixing Machine')->first();
        $fillingMachine = MachineType::where('name', 'Filling Machine')->first();
        $packagingMachine = MachineType::where('name', 'Packaging Machine')->first();
        $conveyorBelt = MachineType::where('name', 'Conveyor Belt')->first();
        $labelingMachine = MachineType::where('name', 'Labeling Machine')->first();
        $cappingMachine = MachineType::where('name', 'Capping Machine')->first();
        $weighingScale = MachineType::where('name', 'Weighing Scale')->first();
        $phMeter = MachineType::where('name', 'pH Meter')->first();
        $spectrophotometer = MachineType::where('name', 'Spectrophotometer')->first();

        // Air Compressor Models
        if ($atlasCopco && $airCompressor) {
            Model::firstOrCreate(
                ['name' => 'AC-200'],
                [
                    'brand_id' => $atlasCopco->id,
                    'type_id' => $airCompressor->id,
                ]
            );
            $this->command->info("Created Model: AC-200 (Atlas Copco - Air Compressor)");
        }

        if ($ingersollRand && $airCompressor) {
            Model::firstOrCreate(
                ['name' => 'AC-150'],
                [
                    'brand_id' => $ingersollRand->id,
                    'type_id' => $airCompressor->id,
                ]
            );
            $this->command->info("Created Model: AC-150 (Ingersoll Rand - Air Compressor)");
        }

        // Blower Exhaust Models
        if ($gardnerDenver && $blowerExhaust) {
            Model::firstOrCreate(
                ['name' => 'BE-500'],
                [
                    'brand_id' => $gardnerDenver->id,
                    'type_id' => $blowerExhaust->id,
                ]
            );
            $this->command->info("Created Model: BE-500 (Gardner Denver - Blower Exhaust)");
        }

        if ($kaeser && $blowerExhaust) {
            Model::firstOrCreate(
                ['name' => 'BE-300'],
                [
                    'brand_id' => $kaeser->id,
                    'type_id' => $blowerExhaust->id,
                ]
            );
            $this->command->info("Created Model: BE-300 (Kaeser - Blower Exhaust)");
        }

        // Boiler Models
        if ($bosch && $boiler) {
            Model::firstOrCreate(
                ['name' => 'BL-1000'],
                [
                    'brand_id' => $bosch->id,
                    'type_id' => $boiler->id,
                ]
            );
            $this->command->info("Created Model: BL-1000 (Bosch - Boiler)");
        }

        if ($cleaverBrooks && $boiler) {
            Model::firstOrCreate(
                ['name' => 'BL-800'],
                [
                    'brand_id' => $cleaverBrooks->id,
                    'type_id' => $boiler->id,
                ]
            );
            $this->command->info("Created Model: BL-800 (Cleaver-Brooks - Boiler)");
        }

        // Generator Set Models
        if ($cummins && $generatorSet) {
            Model::firstOrCreate(
                ['name' => 'GENSET-500KVA'],
                [
                    'brand_id' => $cummins->id,
                    'type_id' => $generatorSet->id,
                ]
            );
            $this->command->info("Created Model: GENSET-500KVA (Cummins - Generator Set)");
        }

        if ($perkins && $generatorSet) {
            Model::firstOrCreate(
                ['name' => 'GENSET-300KVA'],
                [
                    'brand_id' => $perkins->id,
                    'type_id' => $generatorSet->id,
                ]
            );
            $this->command->info("Created Model: GENSET-300KVA (Perkins - Generator Set)");
        }

        // Production Machine Models
        if ($hobart && $mixingMachine) {
            Model::firstOrCreate(
                ['name' => 'MX-500'],
                [
                    'brand_id' => $hobart->id,
                    'type_id' => $mixingMachine->id,
                ]
            );
            $this->command->info("Created Model: MX-500 (Hobart - Mixing Machine)");
        }

        if ($krones && $fillingMachine) {
            Model::firstOrCreate(
                ['name' => 'FM-200'],
                [
                    'brand_id' => $krones->id,
                    'type_id' => $fillingMachine->id,
                ]
            );
            $this->command->info("Created Model: FM-200 (Krones - Filling Machine)");
        }

        if ($krones && $cappingMachine) {
            Model::firstOrCreate(
                ['name' => 'CP-120'],
                [
                    'brand_id' => $krones->id,
                    'type_id' => $cappingMachine->id,
                ]
            );
            $this->command->info("Created Model: CP-120 (Krones - Capping Machine)");
        }

        if ($bosch && $packagingMachine) {
            Model::firstOrCreate(
                ['name' => 'PK-300'],
                [
                    'brand_id' => $bosch->id,
                    'type_id' => $packagingMachine->id,
                ]
            );
            $this->command->info("Created Model: PK-300 (Bosch - Packaging Machine)");
        }

        if ($interroll && $conveyorBelt) {
            Model::firstOrCreate(
                ['name' => 'CV-100'],
                [
                    'brand_id' => $interroll->id,
                    'type_id' => $conveyorBelt->id,
                ]
            );
            $this->command->info("Created Model: CV-100 (Interroll - Conveyor Belt)");
        }

        if ($weber && $labelingMachine) {
            Model::firstOrCreate(
                ['name' => 'LB-150'],
                [
                    'brand_id' => $weber->id,
                    'type_id' => $labelingMachine->id,
                ]
            );
            $this->command->info("Created Model: LB-150 (Weber - Labeling Machine)");
        }

        // Quality Control Models
        if ($mettlerToledo && $weighingScale) {
            Model::firstOrCreate(
                ['name' => 'WS-50'],
                [
                    'brand_id' => $mettlerToledo->id,
                    'type_id' => $weighingScale->id,
                ]
            );
            $this->command->info("Created Model: WS-50 (Mettler Toledo - Weighing Scale)");
        }

        if ($hannaInstruments && $phMeter) {
            Model::firstOrCreate(
                ['name' => 'PH-200'],
                [
                    'brand_id' => $hannaInstruments->id,
                    'type_id' => $phMeter->id,
                ]
            );
            $this->command->info("Created Model: PH-200 (Hanna Instruments - pH Meter)");
        }

        if ($shimadzu && $spectrophotometer) {
            Model::firstOrCreate(
                ['name' => 'SP-100'],
                [
                    'brand_id' => $shimadzu->id,
                    'type_id' => $spectrophotometer->id,
                ]
            );
            $this->command->info("Created Model: SP-100 (Shimadzu - Spectrophotometer)");
        }

        $this->command->info("\nModel seeding completed!");
        $this->command->info("Total models created: " . Model::count());
    }
}

