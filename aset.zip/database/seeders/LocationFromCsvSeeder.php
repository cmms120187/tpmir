<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Plant;
use App\Models\Line;
use App\Models\Process;
use App\Models\Room;
use Illuminate\Support\Facades\DB;

class LocationFromCsvSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $path = base_path('downtime2024revisi.csv');
        if (!file_exists($path)) {
            $this->command->error("CSV file not found: $path");
            return;
        }

        $this->command->info("Reading CSV file...");
        
        // Detect delimiter
        $delimiter = $this->detectDelimiter($path);
        
        $handle = fopen($path, 'r');
        if (!$handle) {
            $this->command->error("Cannot open file: $path");
            return;
        }

        $header = fgetcsv($handle, 0, $delimiter);
        if (!$header) {
            $this->command->error("Cannot read header from CSV");
            fclose($handle);
            return;
        }

        // Normalize header
        $header = array_map(function($h) {
            return trim($h);
        }, $header);

        // Collect unique combinations
        $uniqueCombinations = [];
        $rowCount = 0;

        while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
            if (count($row) !== count($header)) {
                continue;
            }

            $data = array_combine($header, $row);
            
            // Skip if required fields are empty
            if (empty(trim($data['plant'] ?? '')) || 
                empty(trim($data['process'] ?? '')) || 
                empty(trim($data['line'] ?? '')) || 
                empty(trim($data['roomName'] ?? ''))) {
                continue;
            }

            $plant = trim($data['plant']);
            $process = trim($data['process']);
            $line = trim($data['line']);
            $roomName = trim($data['roomName']);

            // Create unique key for combination
            $key = $plant . '|' . $line . '|' . $process . '|' . $roomName;
            
            if (!isset($uniqueCombinations[$key])) {
                $uniqueCombinations[$key] = [
                    'plant' => $plant,
                    'line' => $line,
                    'process' => $process,
                    'roomName' => $roomName,
                ];
            }
            
            $rowCount++;
        }
        fclose($handle);

        $this->command->info("Found " . count($uniqueCombinations) . " unique location combinations from $rowCount rows");

        // Cache for faster lookups
        $plantCache = [];
        $lineCache = [];
        $processCache = [];
        $roomCache = [];

        // First pass: Create all Plants
        $this->command->info("Creating Plants...");
        foreach ($uniqueCombinations as $combo) {
            $plantName = $combo['plant'];
            if (!isset($plantCache[$plantName])) {
                $plant = Plant::firstOrCreate(['name' => $plantName]);
                $plantCache[$plantName] = $plant->id;
            }
        }
        $this->command->info("Created/Found " . count($plantCache) . " plants");

        // Second pass: Create all Processes
        $this->command->info("Creating Processes...");
        foreach ($uniqueCombinations as $combo) {
            $processName = $combo['process'];
            if (!isset($processCache[$processName])) {
                $process = Process::firstOrCreate(['name' => $processName]);
                $processCache[$processName] = $process->id;
            }
        }
        $this->command->info("Created/Found " . count($processCache) . " processes");

        // Third pass: Create all Lines with plant_id
        $this->command->info("Creating Lines with plant relationships...");
        foreach ($uniqueCombinations as $combo) {
            $lineName = $combo['line'];
            $plantName = $combo['plant'];
            $plantId = $plantCache[$plantName];
            
            $lineKey = $plantId . '|' . $lineName;
            if (!isset($lineCache[$lineKey])) {
                $line = Line::firstOrCreate(
                    ['name' => $lineName, 'plant_id' => $plantId],
                    ['plant_id' => $plantId]
                );
                // Update plant_id if line exists but doesn't have plant_id
                if (!$line->plant_id) {
                    $line->update(['plant_id' => $plantId]);
                }
                $lineCache[$lineKey] = $line->id;
            }
        }
        $this->command->info("Created/Updated " . count($lineCache) . " lines");

        // Fourth pass: Create all Rooms with relationships
        $this->command->info("Creating Rooms with plant, line, and process relationships...");
        $roomCount = 0;
        foreach ($uniqueCombinations as $combo) {
            $roomName = $combo['roomName'];
            $plantName = $combo['plant'];
            $lineName = $combo['line'];
            $processName = $combo['process'];
            
            $plantId = $plantCache[$plantName];
            $processId = $processCache[$processName];
            $lineKey = $plantId . '|' . $lineName;
            $lineId = $lineCache[$lineKey] ?? null;
            
            if (!$lineId) {
                $this->command->warn("Line not found for: $lineName in plant: $plantName");
                continue;
            }
            
            // Create or update room with relationships
            $roomKey = $plantId . '|' . $lineId . '|' . $processId . '|' . $roomName;
            if (!isset($roomCache[$roomKey])) {
                $room = Room::firstOrCreate(
                    ['name' => $roomName],
                    [
                        'plant_id' => $plantId,
                        'line_id' => $lineId,
                        'process_id' => $processId,
                        'description' => null,
                    ]
                );
                
                // Update relationships if room exists but doesn't have them or they're different
                if ($room->plant_id != $plantId || $room->line_id != $lineId || $room->process_id != $processId) {
                    $room->update([
                        'plant_id' => $plantId,
                        'line_id' => $lineId,
                        'process_id' => $processId,
                    ]);
                }
                
                $roomCache[$roomKey] = $room->id;
                $roomCount++;
            }
        }
        $this->command->info("Created/Updated $roomCount rooms");

        $this->command->info("Location seeding completed successfully!");
    }

    /**
     * Detect CSV delimiter (tab, semicolon, or comma)
     */
    private function detectDelimiter($filePath)
    {
        $handle = fopen($filePath, 'r');
        $firstLine = fgets($handle);
        fclose($handle);
        
        $delimiters = ["\t", ";", ","];
        $delimiterCounts = [];
        
        foreach ($delimiters as $delimiter) {
            $delimiterCounts[$delimiter] = substr_count($firstLine, $delimiter);
        }
        
        // Return delimiter with highest count
        $detectedDelimiter = array_search(max($delimiterCounts), $delimiterCounts);
        
        // Default to tab if detection fails
        return $detectedDelimiter ?: "\t";
    }
}
