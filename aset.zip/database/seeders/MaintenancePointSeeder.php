<?php

namespace Database\Seeders;

use App\Models\MachineType;
use App\Models\MaintenancePoint;
use Illuminate\Database\Seeder;

class MaintenancePointSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get Machine Types
        $compressor = MachineType::where('name', 'Air Compressor')->where('model', 'AC-200')->first();
        $blower = MachineType::where('name', 'Blower Exhaust')->where('model', 'BE-500')->first();
        $boiler = MachineType::where('name', 'Boiler')->where('model', 'BL-1000')->first();
        $genset = MachineType::where('name', 'Generator Set')->where('model', 'GENSET-500KVA')->first();
        $mixing = MachineType::where('name', 'Mixing Machine')->first();
        $filling = MachineType::where('name', 'Filling Machine')->first();

        // Air Compressor Maintenance Points
        if ($compressor) {
            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Oil Level',
                'instruction' => 'Check compressor oil level. Ensure it is within the recommended range on the sight glass. Top up if necessary using approved compressor oil.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Air Pressure',
                'instruction' => 'Verify air pressure gauge reading. Normal operating pressure should be between 7-8 bar. Report any abnormal readings.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Drain Condensate',
                'instruction' => 'Open drain valve at the bottom of air receiver tank. Drain all accumulated condensate. Close valve securely after draining.',
                'sequence' => 3
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'preventive',
                'frequency_type' => 'weekly',
                'frequency_value' => 1,
                'name' => 'Clean Air Filter',
                'instruction' => 'Remove air filter element. Clean with compressed air or replace if damaged. Reinstall filter element properly.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Change Oil Filter',
                'instruction' => 'Shut down compressor. Drain oil. Replace oil filter element. Refill with new compressor oil. Check for leaks after restart.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Inspect Belts',
                'instruction' => 'Check belt tension and condition. Belts should not be too loose or too tight. Replace if cracked or worn.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'predictive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Vibration Analysis',
                'instruction' => 'Perform vibration analysis on motor and compressor unit. Record vibration levels. Compare with baseline readings.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $compressor->id,
                'category' => 'predictive',
                'frequency_type' => 'quarterly',
                'frequency_value' => 1,
                'name' => 'Thermal Imaging',
                'instruction' => 'Use thermal camera to check for hot spots on motor, bearings, and electrical connections. Document findings.',
                'sequence' => 1
            ]);
        }

        // Blower Exhaust Maintenance Points
        if ($blower) {
            MaintenancePoint::create([
                'machine_type_id' => $blower->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Motor Temperature',
                'instruction' => 'Feel motor housing temperature. Should be warm but not hot. Report if excessively hot.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $blower->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Airflow',
                'instruction' => 'Verify airflow is normal. Check for unusual noise or vibration. Report any abnormalities.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $blower->id,
                'category' => 'preventive',
                'frequency_type' => 'weekly',
                'frequency_value' => 1,
                'name' => 'Clean Impeller',
                'instruction' => 'Shut down blower. Remove access panel. Clean impeller blades from dust and debris. Reinstall panel securely.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $blower->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Lubricate Bearings',
                'instruction' => 'Apply appropriate grease to bearing points. Do not over-grease. Check for grease leakage.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $blower->id,
                'category' => 'preventive',
                'frequency_type' => 'quarterly',
                'frequency_value' => 1,
                'name' => 'Inspect Belts',
                'instruction' => 'Check belt condition and tension. Replace if worn or damaged. Adjust tension if necessary.',
                'sequence' => 1
            ]);
        }

        // Boiler Maintenance Points
        if ($boiler) {
            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Water Level',
                'instruction' => 'Check boiler water level gauge. Water level should be within safe operating range. Top up if low.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Steam Pressure',
                'instruction' => 'Verify steam pressure gauge reading. Normal operating pressure should be as per specification. Report abnormalities.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Blow Down',
                'instruction' => 'Open blowdown valve for 10-15 seconds to remove sediment. Close valve securely. Check water level after blowdown.',
                'sequence' => 3
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'preventive',
                'frequency_type' => 'weekly',
                'frequency_value' => 1,
                'name' => 'Check Safety Valves',
                'instruction' => 'Test safety valve operation. Ensure valve opens at set pressure. Check for leaks.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Water Treatment',
                'instruction' => 'Test water quality. Add treatment chemicals as needed. Maintain proper pH and TDS levels.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'preventive',
                'frequency_type' => 'quarterly',
                'frequency_value' => 1,
                'name' => 'Inspect Burner',
                'instruction' => 'Shut down boiler. Inspect burner assembly. Clean burner nozzles. Check flame pattern. Reassemble and test.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $boiler->id,
                'category' => 'preventive',
                'frequency_type' => 'yearly',
                'frequency_value' => 1,
                'name' => 'Boiler Inspection',
                'instruction' => 'Complete internal and external boiler inspection. Check for corrosion, scale buildup, and structural integrity.',
                'sequence' => 1
            ]);
        }

        // Generator Set Maintenance Points
        if ($genset) {
            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Fuel Level',
                'instruction' => 'Check diesel fuel level in tank. Ensure adequate fuel for operation. Top up if necessary.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Battery Voltage',
                'instruction' => 'Check battery voltage using multimeter. Should be 12.6V or higher. Charge if low.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'autonomous',
                'frequency_type' => 'weekly',
                'frequency_value' => 1,
                'name' => 'Test Run',
                'instruction' => 'Start generator and run for 15-30 minutes under load. Check for unusual noise, smoke, or vibration.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Change Oil',
                'instruction' => 'Drain engine oil. Replace oil filter. Refill with recommended diesel engine oil. Check for leaks.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Replace Air Filter',
                'instruction' => 'Remove and inspect air filter. Replace if dirty or damaged. Clean air filter housing.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Replace Fuel Filter',
                'instruction' => 'Shut down generator. Replace fuel filter element. Bleed air from fuel system. Check for leaks.',
                'sequence' => 3
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'preventive',
                'frequency_type' => 'quarterly',
                'frequency_value' => 1,
                'name' => 'Check Coolant',
                'instruction' => 'Check coolant level and condition. Test coolant concentration. Top up or replace if necessary.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $genset->id,
                'category' => 'preventive',
                'frequency_type' => 'quarterly',
                'frequency_value' => 1,
                'name' => 'Inspect Belts',
                'instruction' => 'Check alternator and fan belts. Adjust tension if loose. Replace if cracked or worn.',
                'sequence' => 2
            ]);
        }

        // Mixing Machine Maintenance Points
        if ($mixing) {
            MaintenancePoint::create([
                'machine_type_id' => $mixing->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Clean Mixing Bowl',
                'instruction' => 'Clean mixing bowl after each batch. Remove all residue. Sanitize if required for food products.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $mixing->id,
                'category' => 'preventive',
                'frequency_type' => 'weekly',
                'frequency_value' => 1,
                'name' => 'Lubricate Gears',
                'instruction' => 'Apply grease to gear assembly. Check gear condition. Report any unusual noise or wear.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $mixing->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Check Mixer Blades',
                'instruction' => 'Inspect mixer blades for wear or damage. Replace if necessary. Check blade alignment.',
                'sequence' => 1
            ]);
        }

        // Filling Machine Maintenance Points
        if ($filling) {
            MaintenancePoint::create([
                'machine_type_id' => $filling->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Clean Filling Nozzles',
                'instruction' => 'Clean all filling nozzles. Remove product residue. Check for clogs. Sanitize if required.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $filling->id,
                'category' => 'autonomous',
                'frequency_type' => 'daily',
                'frequency_value' => 1,
                'name' => 'Check Filling Accuracy',
                'instruction' => 'Verify filling volume accuracy. Adjust if necessary. Record measurements.',
                'sequence' => 2
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $filling->id,
                'category' => 'preventive',
                'frequency_type' => 'weekly',
                'frequency_value' => 1,
                'name' => 'Lubricate Conveyor',
                'instruction' => 'Lubricate conveyor chain and bearings. Check chain tension. Inspect for wear.',
                'sequence' => 1
            ]);

            MaintenancePoint::create([
                'machine_type_id' => $filling->id,
                'category' => 'preventive',
                'frequency_type' => 'monthly',
                'frequency_value' => 1,
                'name' => 'Calibrate Sensors',
                'instruction' => 'Calibrate level sensors and flow meters. Verify accuracy. Document calibration results.',
                'sequence' => 1
            ]);
        }
    }
}
