<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Seed Users
        $this->call(UserSeeder::class);

        // User::factory(10)->create();

        // Create test user if not exists
        User::firstOrCreate(
            ['email' => 'test@example.com'],
            [
                'name' => 'Test User',
                'password' => \Illuminate\Support\Facades\Hash::make('password'),
            ]
        );

        // Seed Rooms (includes Plants, Processes, Lines)
        $this->call(RoomSeeder::class);

        // Seed Systems (must be before Machine Types and Parts)
        $this->call(SystemSeeder::class);

        // Seed Groups (requires Systems)
        $this->call(GroupSeeder::class);

        // Seed Brands (no dependencies)
        $this->call(BrandSeeder::class);

        // Seed Machine Types
        $this->call(MachineTypeSeeder::class);

        // Seed Models (requires Brands and Machine Types)
        $this->call(ModelSeeder::class);

        // Seed Maintenance Points (requires Machine Types)
        $this->call(MaintenancePointSeeder::class);

        // Seed Machines (requires Machine Types and Rooms)
        $this->call(MachineSeeder::class);

        // Seed Parts/Spareparts (requires Machine Types)
        $this->call(PartSeeder::class);

        // Seed Problems (for downtime)
        $this->call(ProblemSeeder::class);

        // Seed Reasons and Actions (for downtime)
        $this->call(ReasonSeeder::class);
        $this->call(ActionSeeder::class);

        // Seed Downtimes (requires Machines, Problems, Reasons, Actions, Users, Groups)
        $this->call(DowntimeSeeder::class);

        // Seed Work Orders (requires Machines, Users)
        $this->call(WorkOrderSeeder::class);

        // Seed Preventive Maintenance (requires Machines, Maintenance Points, Users)
        $this->call(PreventiveMaintenanceSeeder::class);

        // Seed Predictive Maintenance (requires Machines, Maintenance Points, Standards, Users)
        $this->call(PredictiveMaintenanceSeeder::class);

        // Seed Standards (ISO 10816 and Insulation Class Electric Motor)
        $this->call(ISO10816StandardSeeder::class);
        $this->call(InsulationClassElectricMotorSeeder::class);

        // NOTE: CSV-related seeders are NOT called here to avoid duplication
        // If you need to import from CSV, run these seeders manually:
        // - DowntimeCsvSeeder
        // - ImportMachinesFromDowntimeCsvSeeder
        // - LocationFromCsvSeeder
        // - ModelFromDowntimeErpSeeder
        // - UserFromDowntimeErpSeeder
    }
}
