<?php

namespace Database\Seeders;

use App\Models\PredictiveMaintenanceSchedule;
use App\Models\PredictiveMaintenanceExecution;
use App\Models\Machine;
use App\Models\MaintenancePoint;
use App\Models\Standard;
use App\Models\User;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class PredictiveMaintenanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get utility machines (compressor, exhaust blower, boiler, genset)
        $utilityMachines = Machine::whereIn('idMachine', [
            'COMP-001', 'COMP-002', 'COMP-003', // Compressors
            'BLWR-001', // Exhaust Blower
            'BOIL-001', 'BOIL-002', // Boilers
            'GENS-001', 'GENS-002' // Generator Sets
        ])->with('machineType')->get();

        if ($utilityMachines->isEmpty()) {
            $this->command->warn('No utility machines found. Please run MachineSeeder first.');
            return;
        }

        // Get users for assignment
        $mechanics = User::where('role', 'mekanik')->get();
        $teamLeaders = User::where('role', 'team_leader')->get();
        $groupLeaders = User::where('role', 'group_leader')->get();
        $coordinators = User::where('role', 'coordinator')->get();

        $allUsers = $mechanics->merge($teamLeaders)->merge($groupLeaders)->merge($coordinators);

        if ($allUsers->isEmpty()) {
            $this->command->warn('No users found. Please run UserSeeder first.');
            return;
        }

        $schedulesCreated = 0;
        $executionsCreated = 0;
        $currentYear = 2025;

        foreach ($utilityMachines as $machine) {
            if (!$machine->machineType) {
                continue;
            }

            // Get predictive maintenance points for this machine type
            $maintenancePoints = MaintenancePoint::where('machine_type_id', $machine->machine_type_id)
                ->where('category', 'predictive')
                ->orderBy('sequence', 'asc')
                ->get();

            if ($maintenancePoints->isEmpty()) {
                continue;
            }

            // Get or create standards for this machine type
            $standards = $this->getOrCreateStandards($machine->machineType->name, $machine->machine_type_id);

            // Assign a random user to this machine's schedules
            $assignedUser = $allUsers->random();

            // Create schedules for each maintenance point
            foreach ($maintenancePoints as $point) {
                // Get standard for this maintenance point (match by name or use first available)
                $standard = $standards->first();

                if (!$standard) {
                    continue;
                }

                $frequencyType = $point->frequency_type ?? 'monthly';
                $frequencyValue = $point->frequency_value ?? 1;

                // Start from January 1, 2025
                $startDate = Carbon::create($currentYear, 1, 1);
                $endDate = Carbon::create($currentYear, 12, 31);

                // Calculate preferred time (random between 08:00 - 16:00)
                $preferredHour = rand(8, 15);
                $preferredMinute = rand(0, 59);
                $preferredTime = Carbon::createFromTime($preferredHour, $preferredMinute);

                // Estimated duration (60-180 minutes for predictive maintenance)
                $estimatedDuration = rand(60, 180);

                $currentScheduleDate = clone $startDate;

                // Generate schedules until end of year
                while ($currentScheduleDate->lte($endDate)) {
                    // Create schedule
                    $schedule = PredictiveMaintenanceSchedule::firstOrCreate(
                        [
                            'machine_id' => $machine->id,
                            'maintenance_point_id' => $point->id,
                            'standard_id' => $standard->id,
                            'start_date' => $currentScheduleDate->format('Y-m-d'),
                        ],
                        [
                            'title' => $point->name,
                            'description' => $point->instruction ?? 'Predictive maintenance untuk ' . $point->name,
                            'frequency_type' => $frequencyType,
                            'frequency_value' => $frequencyValue,
                            'end_date' => $endDate->format('Y-m-d'),
                            'preferred_time' => $preferredTime->format('H:i:s'),
                            'estimated_duration' => $estimatedDuration,
                            'status' => 'active',
                            'assigned_to' => $assignedUser->id,
                            'notes' => null,
                        ]
                    );

                    $schedulesCreated++;

                    // Create execution for some schedules (70% completed, 15% in_progress, 10% pending, 5% skipped)
                    $executionChance = rand(1, 100);
                    $executionStatus = null;

                    if ($executionChance <= 70) {
                        $executionStatus = 'completed';
                    } elseif ($executionChance <= 85) {
                        $executionStatus = 'in_progress';
                    } elseif ($executionChance <= 95) {
                        $executionStatus = 'pending';
                    } else {
                        $executionStatus = 'skipped';
                    }

                    // Only create execution if status is not null and schedule date is in the past or today
                    if ($executionStatus && $currentScheduleDate->lte(now())) {
                        $performedBy = $allUsers->random();

                        $actualStartTime = null;
                        $actualEndTime = null;

                        // Generate measured value based on standard
                        $measuredValue = $this->generateMeasuredValue($standard, $executionStatus);
                        $measurementStatus = $standard->getMeasurementStatus($measuredValue);

                        if ($executionStatus == 'completed') {
                            // Actual start time: same day, between preferred time and preferred time + 2 hours
                            $actualStartTime = $currentScheduleDate->copy()
                                ->setTime($preferredHour, rand(0, 59))
                                ->addHours(rand(0, 2));

                            // Actual end time: start time + estimated duration + some variance
                            $actualEndTime = $actualStartTime->copy()
                                ->addMinutes($estimatedDuration + rand(-15, 30));
                        } elseif ($executionStatus == 'in_progress') {
                            // Actual start time: same day, between preferred time and preferred time + 2 hours
                            $actualStartTime = $currentScheduleDate->copy()
                                ->setTime($preferredHour, rand(0, 59))
                                ->addHours(rand(0, 2));

                            // No end time yet (in progress)
                            $actualEndTime = null;
                        }

                        // Findings and actions (in Indonesian)
                        $findingsOptions = [
                            'Nilai pengukuran dalam batas normal',
                            'Ditemukan sedikit deviasi dari standar, masih dalam toleransi',
                            'Kondisi mesin normal, tidak ada anomali terdeteksi',
                            'Nilai pengukuran mendekati batas maksimum, perlu monitoring',
                            'Semua parameter dalam kondisi baik',
                            'Ditemukan sedikit peningkatan nilai, masih aman',
                        ];

                        $actionsOptions = [
                            'Tidak ada tindakan yang diperlukan',
                            'Monitoring lebih ketat diperlukan',
                            'Pencatatan data untuk analisis trend',
                            'Pemeriksaan visual tambahan dilakukan',
                            'Semua parameter telah dicatat dan dianalisis',
                            'Tidak ada tindakan korektif yang diperlukan',
                        ];

                        $findings = $executionStatus == 'completed' ? $findingsOptions[array_rand($findingsOptions)] : null;
                        $actionsTaken = $executionStatus == 'completed' ? $actionsOptions[array_rand($actionsOptions)] : null;

                        // Cost (random between 100,000 - 1,000,000 for predictive maintenance)
                        $cost = $executionStatus == 'completed' ? rand(100000, 1000000) : null;

                        // Checklist
                        $checklist = [
                            [
                                'item' => $point->name,
                                'checked' => $executionStatus == 'completed',
                                'notes' => $executionStatus == 'completed' ? 'Pengukuran selesai dilakukan' : null,
                            ],
                        ];

                        PredictiveMaintenanceExecution::firstOrCreate(
                            [
                                'schedule_id' => $schedule->id,
                                'scheduled_date' => $currentScheduleDate->format('Y-m-d'),
                            ],
                            [
                                'actual_start_time' => $actualStartTime ? $actualStartTime->format('Y-m-d H:i:s') : null,
                                'actual_end_time' => $actualEndTime ? $actualEndTime->format('Y-m-d H:i:s') : null,
                                'status' => $executionStatus,
                                'performed_by' => $performedBy->id,
                                'measured_value' => $measuredValue,
                                'measurement_status' => $measurementStatus,
                                'findings' => $findings,
                                'actions_taken' => $actionsTaken,
                                'notes' => $executionStatus == 'completed' ? 'Pengukuran predictive maintenance selesai dilakukan sesuai jadwal' : null,
                                'checklist' => $checklist,
                                'cost' => $cost,
                                'photo_before' => null,
                                'photo_after' => null,
                            ]
                        );

                        $executionsCreated++;
                    }

                    // Calculate next schedule date based on frequency
                    $currentScheduleDate = $this->calculateNextDate($currentScheduleDate, $frequencyType, $frequencyValue);

                    // Safety check to prevent infinite loop
                    if ($schedulesCreated > 5000) {
                        break 2; // Break both loops
                    }
                }
            }
        }

        $this->command->info("Predictive Maintenance Seeder completed:");
        $this->command->info("- Schedules created: {$schedulesCreated}");
        $this->command->info("- Executions created: {$executionsCreated}");
    }

    /**
     * Get or create standards for machine type
     */
    private function getOrCreateStandards($machineTypeName, $machineTypeId)
    {
        $standards = collect();

        // Define standards based on machine type
        if (stripos($machineTypeName, 'Compressor') !== false) {
            // Vibration Analysis Standard
            $vibrationStandard = Standard::firstOrCreate(
                ['name' => 'Standar Getaran Kompresor'],
                [
                    'reference_type' => 'ISO',
                    'reference_code' => 'ISO 10816',
                    'reference_name' => 'ISO 10816 Mechanical vibration - Evaluation of machine vibration',
                    'unit' => 'mm/s',
                    'min_value' => 0,
                    'max_value' => 4.5,
                    'target_value' => 2.0,
                    'description' => 'Standar getaran untuk kompresor udara',
                    'keterangan' => 'Nilai getaran normal: 0-4.5 mm/s',
                    'status' => 'active',
                ]
            );

            // Attach to machine type if not already attached
            if (!$vibrationStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $vibrationStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($vibrationStandard);

            // Temperature Standard
            $tempStandard = Standard::firstOrCreate(
                ['name' => 'Standar Suhu Kompresor'],
                [
                    'reference_type' => 'Factory Standard',
                    'reference_code' => 'FS-COMP-001',
                    'reference_name' => 'Factory Standard - Compressor Temperature',
                    'unit' => '°C',
                    'min_value' => 60,
                    'max_value' => 90,
                    'target_value' => 75,
                    'description' => 'Standar suhu operasi kompresor',
                    'keterangan' => 'Suhu operasi normal: 60-90°C',
                    'status' => 'active',
                ]
            );

            if (!$tempStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $tempStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($tempStandard);
        } elseif (stripos($machineTypeName, 'Blower') !== false || stripos($machineTypeName, 'Exhaust') !== false) {
            // Vibration Standard for Blower
            $vibrationStandard = Standard::firstOrCreate(
                ['name' => 'Standar Getaran Blower'],
                [
                    'reference_type' => 'ISO',
                    'reference_code' => 'ISO 10816',
                    'reference_name' => 'ISO 10816 Mechanical vibration - Evaluation of machine vibration',
                    'unit' => 'mm/s',
                    'min_value' => 0,
                    'max_value' => 7.1,
                    'target_value' => 3.0,
                    'description' => 'Standar getaran untuk blower exhaust',
                    'keterangan' => 'Nilai getaran normal: 0-7.1 mm/s',
                    'status' => 'active',
                ]
            );

            if (!$vibrationStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $vibrationStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($vibrationStandard);

            // Airflow Standard
            $airflowStandard = Standard::firstOrCreate(
                ['name' => 'Standar Aliran Udara Blower'],
                [
                    'reference_type' => 'Factory Standard',
                    'reference_code' => 'FS-BLWR-001',
                    'reference_name' => 'Factory Standard - Blower Airflow',
                    'unit' => 'm³/min',
                    'min_value' => 400,
                    'max_value' => 600,
                    'target_value' => 500,
                    'description' => 'Standar aliran udara blower',
                    'keterangan' => 'Aliran udara normal: 400-600 m³/min',
                    'status' => 'active',
                ]
            );

            if (!$airflowStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $airflowStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($airflowStandard);
        } elseif (stripos($machineTypeName, 'Boiler') !== false) {
            // Pressure Standard
            $pressureStandard = Standard::firstOrCreate(
                ['name' => 'Standar Tekanan Boiler'],
                [
                    'reference_type' => 'Factory Standard',
                    'reference_code' => 'FS-BOIL-001',
                    'reference_name' => 'Factory Standard - Boiler Pressure',
                    'unit' => 'bar',
                    'min_value' => 6,
                    'max_value' => 10,
                    'target_value' => 8,
                    'description' => 'Standar tekanan operasi boiler',
                    'keterangan' => 'Tekanan operasi normal: 6-10 bar',
                    'status' => 'active',
                ]
            );

            if (!$pressureStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $pressureStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($pressureStandard);

            // Temperature Standard
            $tempStandard = Standard::firstOrCreate(
                ['name' => 'Standar Suhu Boiler'],
                [
                    'reference_type' => 'Factory Standard',
                    'reference_code' => 'FS-BOIL-002',
                    'reference_name' => 'Factory Standard - Boiler Temperature',
                    'unit' => '°C',
                    'min_value' => 150,
                    'max_value' => 200,
                    'target_value' => 175,
                    'description' => 'Standar suhu operasi boiler',
                    'keterangan' => 'Suhu operasi normal: 150-200°C',
                    'status' => 'active',
                ]
            );

            if (!$tempStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $tempStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($tempStandard);
        } elseif (stripos($machineTypeName, 'Generator') !== false || stripos($machineTypeName, 'Genset') !== false) {
            // Vibration Standard
            $vibrationStandard = Standard::firstOrCreate(
                ['name' => 'Standar Getaran Genset'],
                [
                    'reference_type' => 'ISO',
                    'reference_code' => 'ISO 10816',
                    'reference_name' => 'ISO 10816 Mechanical vibration - Evaluation of machine vibration',
                    'unit' => 'mm/s',
                    'min_value' => 0,
                    'max_value' => 4.5,
                    'target_value' => 2.0,
                    'description' => 'Standar getaran untuk generator set',
                    'keterangan' => 'Nilai getaran normal: 0-4.5 mm/s',
                    'status' => 'active',
                ]
            );

            if (!$vibrationStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $vibrationStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($vibrationStandard);

            // Voltage Standard
            $voltageStandard = Standard::firstOrCreate(
                ['name' => 'Standar Tegangan Genset'],
                [
                    'reference_type' => 'IEC',
                    'reference_code' => 'IEC 60034',
                    'reference_name' => 'IEC 60034 Rotating electrical machines',
                    'unit' => 'V',
                    'min_value' => 380,
                    'max_value' => 420,
                    'target_value' => 400,
                    'description' => 'Standar tegangan output genset',
                    'keterangan' => 'Tegangan output normal: 380-420V',
                    'status' => 'active',
                ]
            );

            if (!$voltageStandard->machineTypes()->where('machine_types.id', $machineTypeId)->exists()) {
                $voltageStandard->machineTypes()->attach($machineTypeId);
            }
            $standards->push($voltageStandard);
        }

        return $standards;
    }

    /**
     * Generate measured value based on standard and execution status
     */
    private function generateMeasuredValue($standard, $executionStatus)
    {
        if (!$standard->min_value || !$standard->max_value) {
            // If no range, generate around target value
            $target = $standard->target_value ?? 0;
            return $target + rand(-10, 10) / 10;
        }

        $min = $standard->min_value;
        $max = $standard->max_value;
        $range = $max - $min;

        // Generate value based on execution status
        if ($executionStatus == 'completed') {
            // 80% normal, 15% warning, 5% critical
            $chance = rand(1, 100);

            if ($chance <= 80) {
                // Normal: within range
                return $min + ($range * rand(20, 80) / 100);
            } elseif ($chance <= 95) {
                // Warning: close to limit (within 10% of range outside)
                $outsideRange = $range * 0.1;
                if (rand(0, 1)) {
                    // Below min
                    return $min - ($outsideRange * rand(10, 90) / 100);
                } else {
                    // Above max
                    return $max + ($outsideRange * rand(10, 90) / 100);
                }
            } else {
                // Critical: far from range (20-50% of range outside)
                $outsideRange = $range * rand(20, 50) / 100;
                if (rand(0, 1)) {
                    // Below min
                    return $min - $outsideRange;
                } else {
                    // Above max
                    return $max + $outsideRange;
                }
            }
        } else {
            // For pending/in_progress, generate normal values
            return $min + ($range * rand(30, 70) / 100);
        }
    }

    private function calculateNextDate($currentDate, $frequencyType, $frequencyValue = 1)
    {
        $next = clone $currentDate;

        switch ($frequencyType) {
            case 'daily':
                $next->addDays($frequencyValue);
                break;
            case 'weekly':
                $next->addWeeks($frequencyValue);
                break;
            case 'monthly':
                $next->addMonths($frequencyValue);
                break;
            case 'quarterly':
                $next->addMonths($frequencyValue * 3);
                break;
            case 'yearly':
                $next->addYears($frequencyValue);
                break;
            default:
                // Default to monthly
                $next->addMonths($frequencyValue);
                break;
        }

        return $next;
    }
}
