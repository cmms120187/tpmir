<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Downtime;
use App\Models\Machine;
use App\Models\Problem;
use App\Models\Reason;
use App\Models\Action;
use App\Models\Group;
use App\Models\User;
use App\Models\Part;
use Carbon\Carbon;

class DowntimeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get machines (utility machines)
        $machines = Machine::whereIn('idMachine', ['COMP-001', 'COMP-002', 'COMP-003', 'BLWR-001', 'BOIL-001', 'BOIL-002', 'GENS-001', 'GENS-002'])->get()->keyBy('idMachine');

        // Get problems
        $problems = Problem::all()->keyBy('name');

        // Get reasons and actions
        $reasons = Reason::all();
        $actions = Action::all();

        // Get default group (use Compressing as default, or first available group)
        $defaultGroup = Group::where('name', 'Compressing')->first();
        if (!$defaultGroup) {
            $defaultGroup = Group::orderBy('name', 'asc')->first();
        }
        if (!$defaultGroup) {
            // Fallback: create Compressing group if no groups exist
            $defaultGroup = Group::firstOrCreate(['name' => 'Compressing']);
        }

        // Get users by role (mekanik, team_leader, coordinator)
        $mechanics = User::where('role', 'mekanik')->get();
        if ($mechanics->isEmpty()) {
            // Fallback to users with specific emails if no mekanik role found
            $mechanics = User::whereIn('email', [
                'ahmad.rizki@tpmcmms.id',
                'budi.santoso@tpmcmms.id',
                'cahyo.wibowo@tpmcmms.id',
                'dedi.kurniawan@tpmcmms.id',
                'eko.prasetyo@tpmcmms.id',
            ])->get();
        }

        $leaders = User::where('role', 'team_leader')->get();
        if ($leaders->isEmpty()) {
            // Fallback to users with specific emails if no team_leader role found
            $leaders = User::whereIn('email', [
                'kurniawan.adi@tpmcmms.id',
                'lukman.hakim@tpmcmms.id',
                'mulyadi.sari@tpmcmms.id',
            ])->get();
        }

        $coords = User::where('role', 'coordinator')->get();
        if ($coords->isEmpty()) {
            // Fallback to users with specific emails if no coordinator role found
            $coords = User::whereIn('email', [
                'fajar.hidayat@tpmcmms.id',
                'gunawan.sari@tpmcmms.id',
                'prasetyo.adi@tpmcmms.id',
                'rizki.kurniawan@tpmcmms.id',
            ])->get();
        }

        // Get parts for sparepart usage
        $parts = Part::all();

        // Problems mapping to machines (dalam bahasa Indonesia)
        $problemMachineMap = [
            'COMP-001' => ['Kompresor Overheating', 'Kebocoran Udara di Sistem', 'Motor Kompresor Rusak', 'Filter Oli Kompresor Tersumbat', 'Pressure Switch Bermasalah', 'Belt Slippage', 'Aftercooler Tidak Berfungsi'],
            'COMP-002' => ['Kompresor Overheating', 'Kebocoran Udara di Sistem', 'Motor Kompresor Rusak', 'Filter Oli Kompresor Tersumbat', 'Pressure Switch Bermasalah'],
            'COMP-003' => ['Kompresor Overheating', 'Kebocoran Udara di Sistem', 'Belt Slippage', 'Aftercooler Tidak Berfungsi'],
            'BLWR-001' => ['Impeller Blower Rusak', 'Bearing Motor Rusak', 'V-Belt Putus', 'Motor Blower Overload', 'Aliran Udara Tidak Cukup'],
            'BOIL-001' => ['Level Air Boiler Rendah', 'Nozzle Burner Tersumbat', 'Temperature Controller Rusak', 'Safety Valve Bocor', 'Heating Element Terbakar', 'Pressure Gauge Rusak', 'Thermocouple Bermasalah', 'Insulasi Boiler Rusak'],
            'BOIL-002' => ['Level Air Boiler Rendah', 'Nozzle Burner Tersumbat', 'Temperature Controller Rusak', 'Safety Valve Bocor', 'Heating Element Terbakar'],
            'GENS-001' => ['Mesin Generator Overheating', 'Filter Bahan Bakar Tersumbat', 'Busi Kotor', 'Filter Oli Generator Tersumbat', 'Radiator Bocor', 'Baterai Mati', 'Alternator Rusak', 'Fluktuasi Tegangan Generator'],
            'GENS-002' => ['Mesin Generator Overheating', 'Filter Bahan Bakar Tersumbat', 'Busi Kotor', 'Filter Oli Generator Tersumbat', 'Radiator Bocor', 'Baterai Mati'],
        ];

        // Parts mapping to problems (dalam bahasa Indonesia)
        $problemPartMap = [
            'Filter Oli Kompresor Tersumbat' => ['Compressor Oil Filter'],
            'Filter Oli Generator Tersumbat' => ['Generator Oil Filter'],
            'Belt Slippage' => ['V-Belt A-50', 'Blower V-Belt'],
            'Bearing Motor Rusak' => ['Bearing 6205-2RS', 'Blower Motor Bearing'],
            'Impeller Blower Rusak' => ['Blower Impeller'],
            'Safety Valve Bocor' => ['Boiler Safety Valve'],
            'Nozzle Burner Tersumbat' => ['Boiler Burner Nozzle'],
            'Temperature Controller Rusak' => ['Boiler Temperature Controller'],
            'Heating Element Terbakar' => ['Boiler Heating Element'],
            'Pressure Gauge Rusak' => ['Boiler Pressure Gauge'],
            'Thermocouple Bermasalah' => ['Boiler Thermocouple K-Type'],
            'Insulasi Boiler Rusak' => ['Boiler Insulation Material'],
            'Busi Kotor' => ['Generator Spark Plug'],
            'Filter Bahan Bakar Tersumbat' => ['Generator Fuel Filter'],
            'Radiator Bocor' => ['Generator Radiator'],
            'Aftercooler Tidak Berfungsi' => ['Compressor Aftercooler'],
        ];

        $downtimes = [];
        $startDate = Carbon::create(2025, 1, 1);
        $endDate = Carbon::create(2025, 12, 31);

        // Generate at least 20 downtimes per month
        for ($month = 1; $month <= 12; $month++) {
            $daysInMonth = Carbon::create(2025, $month, 1)->daysInMonth;
            $downtimesPerMonth = max(20, rand(20, 35)); // At least 20, up to 35 per month

            for ($i = 0; $i < $downtimesPerMonth; $i++) {
                // Random day in month
                $day = rand(1, $daysInMonth);
                $date = Carbon::create(2025, $month, $day);

                // Random machine
                $machineIds = array_keys($problemMachineMap);
                $machineId = $machineIds[array_rand($machineIds)];
                $machine = $machines->get($machineId);

                if (!$machine) continue;

                // Random problem for this machine
                $availableProblems = $problemMachineMap[$machineId];
                $problemName = $availableProblems[array_rand($availableProblems)];
                $problem = $problems->get($problemName);

                if (!$problem) continue;

                // Random time during working hours (8 AM - 5 PM)
                $hour = rand(8, 16);
                $minute = rand(0, 59);
                $stopProduction = $date->copy()->setTime($hour, $minute);

                // Response time: 5-30 minutes after stop
                $responseMinutes = rand(5, 30);
                $responMechanic = $stopProduction->copy()->addMinutes($responseMinutes);

                // Duration: 15 minutes to 4 hours
                $durationMinutes = rand(15, 240);
                $startProduction = $responMechanic->copy()->addMinutes($durationMinutes);

                // Random users
                $mekanik = $mechanics->random();
                $leader = $leaders->random();
                $coord = $coords->random();

                // Random reason and action
                $reason = $reasons->random();
                $action = $actions->random();

                // Determine if uses sparepart (45% chance)
                $usesSparepart = rand(1, 100) <= 45;
                $selectedParts = [];
                $repairCost = 0;

                if ($usesSparepart && $parts->isNotEmpty()) {
                    // Jika problem ada di mapping, gunakan parts yang sesuai
                    if (isset($problemPartMap[$problemName]) && !empty($problemPartMap[$problemName])) {
                        $availableParts = $problemPartMap[$problemName];
                    } else {
                        // Jika tidak ada di mapping, gunakan semua parts yang tersedia
                        $availableParts = $parts->pluck('name')->toArray();
                    }

                    // Pastikan ada parts yang tersedia
                    if (!empty($availableParts)) {
                        // Distribusi: 50% menggunakan 1 part, 30% menggunakan 2 parts, 20% menggunakan 3 parts
                        $randomDist = rand(1, 100);
                        if ($randomDist <= 50) {
                            $numParts = 1; // 50% menggunakan 1 sparepart
                        } elseif ($randomDist <= 80) {
                            $numParts = 2; // 30% menggunakan 2 sparepart
                        } else {
                            $numParts = min(3, count($availableParts)); // 20% menggunakan 3 sparepart (atau maksimal yang tersedia)
                        }

                        // Pastikan numParts tidak 0
                        $numParts = max(1, $numParts);

                        // Shuffle dan ambil N parts pertama
                        $shuffledParts = $availableParts;
                        shuffle($shuffledParts);
                        $selectedPartNames = array_slice($shuffledParts, 0, $numParts);

                        // Find part IDs by name and calculate cost
                        foreach ($selectedPartNames as $partName) {
                            $part = $parts->firstWhere('name', $partName);
                            if ($part) {
                                // Quantity: 1-3 untuk single part, 1-2 untuk multiple parts
                                $maxQuantity = $numParts == 1 ? 3 : 2;
                                $quantity = rand(1, $maxQuantity);
                                $selectedParts[$part->id] = ['quantity' => $quantity];

                                // Calculate cost: part price * quantity
                                if ($part->price) {
                                    $repairCost += $part->price * $quantity;
                                }
                            }
                        }
                    }
                }

                // Jika tidak ada sparepart atau biaya masih 0, tambahkan biaya jasa perbaikan
                if ($repairCost == 0) {
                    // Biaya jasa perbaikan manual (tanpa sparepart): 50,000 - 500,000
                    $repairCost = rand(50000, 500000);
                } else {
                    // Tambahkan biaya jasa perbaikan (20-30% dari biaya sparepart)
                    $serviceCost = $repairCost * (rand(20, 30) / 100);
                    $repairCost += $serviceCost;
                }

                $downtimes[] = [
                    'machine_id' => $machine->id,
                    'date' => $date->format('Y-m-d'),
                    'stopProduction' => $stopProduction,
                    'responMechanic' => $responMechanic,
                    'startProduction' => $startProduction,
                    'duration' => $durationMinutes,
                    'repair_cost' => round($repairCost, 2),
                    'standard_time' => null,
                    'problem_id' => $problem->id,
                    'problem_mm_id' => null,
                    'reason_id' => $reason->id,
                    'action_id' => $action->id,
                    'group_id' => $defaultGroup->id,
                    'mekanik_id' => $mekanik->id,
                    'leader_id' => $leader->id,
                    'coord_id' => $coord->id,
                    'created_at' => now(),
                    'updated_at' => now(),
                    '_parts' => $selectedParts, // Temporary storage for parts
                ];
            }
        }

        // Insert in batches and attach parts
        foreach (array_chunk($downtimes, 100) as $chunk) {
            foreach ($chunk as $downtimeData) {
                $partsData = $downtimeData['_parts'] ?? [];
                unset($downtimeData['_parts']);

                $downtime = Downtime::create($downtimeData);

                // Attach parts with quantities
                if (!empty($partsData)) {
                    $downtime->parts()->attach($partsData);
                }
            }
        }
    }
}
