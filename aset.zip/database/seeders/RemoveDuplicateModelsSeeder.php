<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Model;
use App\Models\Machine;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class RemoveDuplicateModelsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->command->info("Menghapus duplikat Model berdasarkan name...");
        
        // Find duplicate models by name
        $duplicates = Model::select('name', DB::raw('COUNT(*) as count'), DB::raw('MIN(id) as min_id'))
            ->groupBy('name')
            ->havingRaw('COUNT(*) > 1')
            ->get();
        
        $deletedCount = 0;
        $updatedMachinesCount = 0;
        
        DB::beginTransaction();
        try {
            foreach ($duplicates as $duplicate) {
                $this->command->info("Memproses duplikat: {$duplicate->name} (Total: {$duplicate->count})");
                
                // Get the model with the smallest ID (keep this one)
                $keepModel = Model::where('name', $duplicate->name)
                    ->orderBy('id', 'asc')
                    ->first();
                
                // Get all other models with the same name (these will be deleted)
                $deleteModels = Model::where('name', $duplicate->name)
                    ->where('id', '>', $keepModel->id)
                    ->get();
                
                foreach ($deleteModels as $deleteModel) {
                    // Update all machines that use this model to use the kept model
                    $machinesUpdated = Machine::where('model_id', $deleteModel->id)
                        ->update(['model_id' => $keepModel->id]);
                    
                    $updatedMachinesCount += $machinesUpdated;
                    
                    if ($machinesUpdated > 0) {
                        $this->command->info("  - Updated {$machinesUpdated} machines from model ID {$deleteModel->id} to {$keepModel->id}");
                    }
                    
                    // Delete the duplicate model
                    $deleteModel->delete();
                    $deletedCount++;
                    
                    $this->command->info("  - Deleted model ID {$deleteModel->id} (name: {$deleteModel->name})");
                }
            }
            
            DB::commit();
            
            // Now add unique constraint to name column using Schema (outside transaction)
            if (Schema::hasTable('models')) {
                try {
                    Schema::table('models', function (Blueprint $table) {
                        $table->unique('name', 'models_name_unique');
                    });
                    $this->command->info("Unique constraint added to models.name");
                } catch (\Exception $e) {
                    // Constraint might already exist
                    $this->command->warn("Could not add unique constraint: " . $e->getMessage());
                }
            }
            
            $this->command->info("\n=== Hasil ===");
            $this->command->info("Model duplikat yang dihapus: {$deletedCount}");
            $this->command->info("Machines yang diupdate: {$updatedMachinesCount}");
            $this->command->info("Unique constraint berhasil ditambahkan ke models.name");
            
        } catch (\Exception $e) {
            DB::rollBack();
            $this->command->error("Error: " . $e->getMessage());
            \Log::error("Error in RemoveDuplicateModelsSeeder: " . $e->getMessage());
        }
    }
}
