<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LineController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $lines = \App\Models\Line::with(['plant', 'process'])
            ->orderBy('name', 'asc')
            ->paginate(12);
        return view('lines.index', compact('lines'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $plants = \App\Models\Plant::orderBy('name', 'asc')->get();
        $processes = \App\Models\Process::orderBy('name', 'asc')->get();
        return view('lines.create', compact('plants', 'processes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'plant_id' => 'required|exists:plants,id',
            'process_id' => 'required|exists:processes,id',
        ]);
        $line = new \App\Models\Line();
        $line->name = $validated['name'];
        $line->plant_id = $validated['plant_id'];
        $line->process_id = $validated['process_id'];
        $line->save();
        return redirect()->route('lines.index')->with('success', 'Line created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $line = \App\Models\Line::findOrFail($id);
        $plants = \App\Models\Plant::orderBy('name', 'asc')->get();
        $processes = \App\Models\Process::orderBy('name', 'asc')->get();
        return view('lines.edit', compact('line', 'plants', 'processes'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'plant_id' => 'required|exists:plants,id',
            'process_id' => 'required|exists:processes,id',
        ]);
        $line = \App\Models\Line::findOrFail($id);
        $line->name = $validated['name'];
        $line->plant_id = $validated['plant_id'];
        $line->process_id = $validated['process_id'];
        $line->save();
        return redirect()->route('lines.index')->with('success', 'Line updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $line = \App\Models\Line::findOrFail($id);
        $line->delete();
        return redirect()->route('lines.index')->with('success', 'Line deleted successfully.');
    }
}
