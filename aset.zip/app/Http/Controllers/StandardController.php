<?php

namespace App\Http\Controllers;

use App\Models\Standard;
use App\Models\MachineType;
use App\Models\StandardPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class StandardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $standards = Standard::with('machineTypes', 'photos')
            ->orderBy('name', 'asc')
            ->paginate(20);
        
        return view('standards.index', compact('standards'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $machineTypes = MachineType::orderBy('name')->get();
        $standardPhotos = StandardPhoto::orderBy('name')->get();
        return view('standards.create', compact('machineTypes', 'standardPhotos'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'reference_type' => 'nullable|string|max:255',
            'reference_code' => 'nullable|string|max:255',
            'reference_name' => 'nullable|string|max:255',
            'unit' => 'nullable|string|max:50',
            'min_value' => 'nullable|numeric',
            'max_value' => 'nullable|numeric',
            'target_value' => 'nullable|numeric',
            'description' => 'nullable|string',
            'keterangan' => 'nullable|string',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'photo_name' => 'nullable|string|max:255',
            'standard_photo_ids' => 'nullable|array',
            'standard_photo_ids.*' => 'exists:standard_photos,id',
            'machine_type_ids' => 'nullable|array',
            'machine_type_ids.*' => 'exists:machine_types,id',
            'status' => 'required|in:active,inactive',
        ]);

        // Handle photo selection and upload
        $standardPhotoIds = $validated['standard_photo_ids'] ?? [];
        
        // If new photo is uploaded, create new StandardPhoto
        if ($request->hasFile('photo')) {
            $photoPath = $request->file('photo')->store('standards', 'public');
            $standardPhoto = StandardPhoto::create([
                'name' => $validated['photo_name'] ?? 'Photo ' . date('Y-m-d H:i:s'),
                'photo_path' => $photoPath,
                'description' => null,
            ]);
            $standardPhotoIds[] = $standardPhoto->id;
        }

        // Remove photo field from validated (we use standard_photos table now)
        unset($validated['photo']);

        unset($validated['photo_name']);
        unset($validated['standard_photo_ids']);

        $machineTypeIds = $validated['machine_type_ids'] ?? [];
        unset($validated['machine_type_ids']);

        $standard = Standard::create($validated);
        
        // Attach machine types
        if (!empty($machineTypeIds)) {
            $standard->machineTypes()->attach($machineTypeIds);
        }

        // Attach photos
        if (!empty($standardPhotoIds)) {
            $standard->photos()->attach($standardPhotoIds);
        }

        return redirect()->route('standards.index')
            ->with('success', 'Standard berhasil dibuat.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $standard = Standard::with('machineTypes', 'predictiveMaintenanceSchedules', 'photos')->findOrFail($id);
        return view('standards.show', compact('standard'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $standard = Standard::with('photos')->findOrFail($id);
        $machineTypes = MachineType::orderBy('name')->get();
        $standardPhotos = StandardPhoto::orderBy('name')->get();
        return view('standards.edit', compact('standard', 'machineTypes', 'standardPhotos'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'reference_type' => 'nullable|string|max:255',
            'reference_code' => 'nullable|string|max:255',
            'reference_name' => 'nullable|string|max:255',
            'unit' => 'nullable|string|max:50',
            'min_value' => 'nullable|numeric',
            'max_value' => 'nullable|numeric',
            'target_value' => 'nullable|numeric',
            'description' => 'nullable|string',
            'keterangan' => 'nullable|string',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'photo_name' => 'nullable|string|max:255',
            'standard_photo_ids' => 'nullable|array',
            'standard_photo_ids.*' => 'exists:standard_photos,id',
            'machine_type_ids' => 'nullable|array',
            'machine_type_ids.*' => 'exists:machine_types,id',
            'status' => 'required|in:active,inactive',
        ]);

        $standard = Standard::findOrFail($id);
        
        // Handle photo selection and upload
        $standardPhotoIds = $validated['standard_photo_ids'] ?? [];
        
        // If new photo is uploaded, create new StandardPhoto
        if ($request->hasFile('photo')) {
            $photoPath = $request->file('photo')->store('standards', 'public');
            $standardPhoto = StandardPhoto::create([
                'name' => $validated['photo_name'] ?? 'Photo ' . date('Y-m-d H:i:s'),
                'photo_path' => $photoPath,
                'description' => null,
            ]);
            $standardPhotoIds[] = $standardPhoto->id;
        }

        // Remove photo field from validated (we use standard_photos table now)
        unset($validated['photo']);

        unset($validated['photo_name']);
        unset($validated['standard_photo_ids']);
        
        $machineTypeIds = $validated['machine_type_ids'] ?? [];
        unset($validated['machine_type_ids']);
        
        $standard->update($validated);
        
        // Sync machine types
        $standard->machineTypes()->sync($machineTypeIds);

        // Sync photos
        $standard->photos()->sync($standardPhotoIds);

        return redirect()->route('standards.index')
            ->with('success', 'Standard berhasil diupdate.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $standard = Standard::findOrFail($id);
        
        // Check if standard is used in any schedules
        if ($standard->predictiveMaintenanceSchedules()->count() > 0) {
            return redirect()->route('standards.index')
                ->with('error', 'Tidak dapat menghapus standard yang sedang digunakan dalam jadwal.');
        }
        
        // Delete photo if exists
        if ($standard->photo && Storage::disk('public')->exists($standard->photo)) {
            Storage::disk('public')->delete($standard->photo);
        }
        
        $standard->delete();

        return redirect()->route('standards.index')
            ->with('success', 'Standard berhasil dihapus.');
    }
}
