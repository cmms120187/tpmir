<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MachineType;
use App\Models\MaintenancePoint;
use App\Models\Group;
use App\Models\System;
use Illuminate\Support\Facades\Storage;

class MachineTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $machine_types = MachineType::with(['groupRelation', 'systems'])
                                    ->withCount('maintenancePoints')
                                    ->orderBy('name', 'asc')
                                    ->paginate(12);
        return view('machinary.group.index', compact('machine_types'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $groups = Group::with('systems')->orderBy('name')->get();
        $systems = System::orderBy('nama_sistem')->get();
        return view('machinary.group.create', compact('groups', 'systems'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:machine_types,name',
            'model' => 'nullable|string|max:255',
            'group_id' => 'nullable|exists:groups,id',
            'brand' => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'systems' => 'nullable|array',
            'systems.*' => 'exists:systems,id',
        ]);
        
        $machineType = MachineType::create($validated);
        
        // Auto-sync systems from group if group_id is provided
        if ($request->filled('group_id')) {
            $group = Group::with('systems')->find($request->group_id);
            if ($group && $group->systems->isNotEmpty()) {
                $machineType->systems()->sync($group->systems->pluck('id')->toArray());
            }
        } elseif ($request->filled('systems')) {
            // If systems are manually selected, use those
            $machineType->systems()->sync($request->input('systems', []));
        }

        // Handle maintenance points if provided
        if ($request->has('maintenance_points')) {
            foreach ($request->maintenance_points as $index => $point) {
                if (!empty($point['name'])) {
                    $photoPath = null;
                    // Handle photo upload if exists
                    if ($request->hasFile("maintenance_points.{$index}.photo")) {
                        $photo = $request->file("maintenance_points.{$index}.photo");
                        $photoPath = $photo->store('maintenance-points', 'public');
                    }
                    
                    MaintenancePoint::create([
                        'machine_type_id' => $machineType->id,
                        'category' => $point['category'] ?? 'preventive',
                        'frequency_type' => $point['frequency_type'] ?? null,
                        'frequency_value' => $point['frequency_value'] ?? 1,
                        'name' => $point['name'],
                        'instruction' => $point['instruction'] ?? null,
                        'sequence' => $point['sequence'] ?? 0,
                        'photo' => $photoPath,
                    ]);
                }
            }
        }

        return redirect()->route('machine-types.index')->with('success', 'Machine Type created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $machineType = MachineType::with([
            'groupRelation',
            'systems',
            'maintenancePoints' => function($query) {
                $query->orderBy('category')->orderBy('sequence');
            }
        ])->findOrFail($id);
        
        // Group points by category
        $points = $machineType->maintenancePoints->groupBy('category');
        
        return view('machinary.group.show', compact('machineType', 'points'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $machineType = MachineType::with(['maintenancePoints' => function($query) {
            $query->orderBy('category')->orderBy('sequence');
        }, 'groupRelation.systems', 'systems'])->findOrFail($id);
        
        // Group points by category
        $points = $machineType->maintenancePoints->groupBy('category');
        
        $groups = Group::with('systems')->orderBy('name')->get();
        $systems = System::orderBy('nama_sistem')->get();
        
        return view('machinary.group.edit', compact('machineType', 'points', 'groups', 'systems'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:machine_types,name,' . $id,
            'model' => 'nullable|string|max:255',
            'group_id' => 'nullable|exists:groups,id',
            'brand' => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'systems' => 'nullable|array',
            'systems.*' => 'exists:systems,id',
        ]);
        
        $machineType = MachineType::findOrFail($id);
        $machineType->update($validated);
        
        // Auto-sync systems from group if group_id is provided
        if ($request->filled('group_id')) {
            $group = Group::with('systems')->find($request->group_id);
            if ($group && $group->systems->isNotEmpty()) {
                $machineType->systems()->sync($group->systems->pluck('id')->toArray());
            } else {
                // If group has no systems, clear systems
                $machineType->systems()->sync([]);
            }
        } elseif ($request->has('systems')) {
            // If systems are manually selected, use those
            $machineType->systems()->sync($request->input('systems', []));
        }

        // Handle maintenance points if provided
        if ($request->has('maintenance_points')) {
            foreach ($request->maintenance_points as $point) {
                if (!empty($point['name'])) {
                    if (isset($point['id']) && $point['id']) {
                        // Update existing point
                        $existingPoint = MaintenancePoint::find($point['id']);
                        if ($existingPoint && $existingPoint->machine_type_id == $machineType->id) {
                            $existingPoint->update([
                                'category' => $point['category'] ?? 'preventive',
                                'name' => $point['name'],
                                'instruction' => $point['instruction'] ?? null,
                                'sequence' => $point['sequence'] ?? 0,
                            ]);
                        }
                    } else {
                        // Create new point
                        MaintenancePoint::create([
                            'machine_type_id' => $machineType->id,
                            'category' => $point['category'] ?? 'preventive',
                            'name' => $point['name'],
                            'instruction' => $point['instruction'] ?? null,
                            'sequence' => $point['sequence'] ?? 0,
                        ]);
                    }
                }
            }
        }

        return redirect()->route('machine-types.index')->with('success', 'Machine Type updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $machineType = MachineType::findOrFail($id);
        $machineType->delete();
        return redirect()->route('machine-types.index')->with('success', 'Machine Type deleted successfully.');
    }

    /**
     * Store a maintenance point for a machine type.
     */
    public function storeMaintenancePoint(Request $request, $machineTypeId)
    {
        $validated = $request->validate([
            'category' => 'required|in:autonomous,preventive,predictive',
            'frequency_type' => 'nullable|in:daily,weekly,monthly,quarterly,yearly,custom',
            'frequency_value' => 'nullable|integer|min:1',
            'name' => 'required|string|max:255',
            'instruction' => 'nullable|string',
            'sequence' => 'nullable|integer|min:0',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $machineType = MachineType::findOrFail($machineTypeId);

        $photoPath = null;
        // Handle photo upload
        if ($request->hasFile('photo')) {
            $photo = $request->file('photo');
            $photoPath = $photo->store('maintenance-points', 'public');
        }

        MaintenancePoint::create([
            'machine_type_id' => $machineType->id,
            'category' => $validated['category'],
            'frequency_type' => $validated['frequency_type'] ?? null,
            'frequency_value' => $validated['frequency_value'] ?? 1,
            'name' => $validated['name'],
            'instruction' => $validated['instruction'] ?? null,
            'sequence' => $validated['sequence'] ?? 0,
            'photo' => $photoPath,
        ]);

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Point maintenance berhasil ditambahkan.'
            ]);
        }

        return redirect()->route('machine-types.edit', $machineType->id)
            ->with('success', 'Point maintenance berhasil ditambahkan.');
    }

    /**
     * Update a maintenance point.
     */
    public function updateMaintenancePoint(Request $request, $id)
    {
        $validated = $request->validate([
            'category' => 'required|in:autonomous,preventive,predictive',
            'frequency_type' => 'nullable|in:daily,weekly,monthly,quarterly,yearly,custom',
            'frequency_value' => 'nullable|integer|min:1',
            'name' => 'required|string|max:255',
            'instruction' => 'nullable|string',
            'sequence' => 'nullable|integer|min:0',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $point = MaintenancePoint::findOrFail($id);
        
        // Handle photo upload
        if ($request->hasFile('photo')) {
            // Delete old photo if exists
            if ($point->photo && Storage::disk('public')->exists($point->photo)) {
                Storage::disk('public')->delete($point->photo);
            }
            
            $photo = $request->file('photo');
            $photoPath = $photo->store('maintenance-points', 'public');
            $validated['photo'] = $photoPath;
        }
        
        $point->update($validated);

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Point maintenance berhasil diupdate.'
            ]);
        }

        return redirect()->route('machine-types.edit', $point->machine_type_id)
            ->with('success', 'Point maintenance berhasil diupdate.');
    }

    /**
     * Delete a maintenance point.
     */
    public function destroyMaintenancePoint($id)
    {
        $point = MaintenancePoint::findOrFail($id);
        $machineTypeId = $point->machine_type_id;
        
        // Delete photo if exists
        if ($point->photo && Storage::disk('public')->exists($point->photo)) {
            Storage::disk('public')->delete($point->photo);
        }
        
        $point->delete();

        return redirect()->route('machine-types.edit', $machineTypeId)
            ->with('success', 'Point maintenance berhasil dihapus.');
    }
}
