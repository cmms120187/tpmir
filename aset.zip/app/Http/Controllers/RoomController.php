<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Room;
use App\Models\Plant;
use App\Models\Line;
use App\Models\Process;

class RoomController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $rooms = Room::with(['plant', 'line'])
            ->leftJoin('plants', 'rooms.plant_id', '=', 'plants.id')
            ->select('rooms.*')
            ->orderBy('plants.name', 'asc')
            ->orderBy('rooms.name', 'asc')
            ->paginate(12);
        return view('rooms.index', compact('rooms'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $plants = Plant::all();
        return view('rooms.create', compact('plants'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'plant_id' => 'required|exists:plants,id',
            'line_id' => 'required|exists:lines,id',
            'category' => 'nullable|in:Production,Supporting,Warehouse,Other',
            'description' => 'nullable|string',
        ]);

        // Validate that the selected line belongs to the selected plant
        $line = Line::findOrFail($validated['line_id']);
        if ($line->plant_id != $validated['plant_id']) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['line_id' => 'Line yang dipilih tidak sesuai dengan Plant yang dipilih.']);
        }
        
        Room::create($validated);
        return redirect()->route('rooms.index')->with('success', 'Room created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $room = Room::with(['plant', 'line'])->findOrFail($id);
        $plants = Plant::all();
        $lines = Line::where('plant_id', $room->plant_id)->get();
        return view('rooms.edit', compact('room', 'plants', 'lines'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'plant_id' => 'required|exists:plants,id',
            'line_id' => 'required|exists:lines,id',
            'category' => 'nullable|in:Production,Supporting,Warehouse,Other',
            'description' => 'nullable|string',
        ]);

        // Validate that the selected line belongs to the selected plant
        $line = Line::findOrFail($validated['line_id']);
        if ($line->plant_id != $validated['plant_id']) {
            return redirect()->back()
                ->withInput()
                ->withErrors(['line_id' => 'Line yang dipilih tidak sesuai dengan Plant yang dipilih.']);
        }
        
        $room = Room::findOrFail($id);
        $room->update($validated);
        return redirect()->route('rooms.index')->with('success', 'Room updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $room = Room::findOrFail($id);
        $room->delete();
        return redirect()->route('rooms.index')->with('success', 'Room deleted successfully.');
    }

    /**
     * Get lines by plant_id (for AJAX)
     */
    public function getLinesByPlant(Request $request)
    {
        try {
            $plantId = $request->query('plant_id') ?? $request->input('plant_id');
            
            if (!$plantId) {
                return response()->json([], 200);
            }
            
            if (!is_numeric($plantId)) {
                return response()->json([
                    'error' => 'Invalid plant_id'
                ], 400);
            }
            
            $lines = Line::where('plant_id', (int)$plantId)
                ->orderBy('name', 'asc')
                ->get(['id', 'name']);
            
            $data = $lines->map(function($line) {
                return [
                    'id' => (int)$line->id,
                    'name' => (string)$line->name
                ];
            })->values()->all();
            
            return response()->json($data, 200, [
                'Content-Type' => 'application/json',
            ]);
                
        } catch (\Exception $e) {
            \Log::error('Error in getLinesByPlant: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
                'plant_id' => $request->get('plant_id')
            ]);
            
            return response()->json([
                'error' => 'Error fetching lines: ' . $e->getMessage()
            ], 500);
        }
    }
}
