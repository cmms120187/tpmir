<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ModelController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $models = \App\Models\Model::with(['brand', 'machineType'])
            ->orderBy('name', 'asc')
            ->paginate(12);
        return view('models.index', compact('models'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $brands = \App\Models\Brand::all();
        $machineTypes = \App\Models\MachineType::all();
        return view('models.create', compact('brands', 'machineTypes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:models,name',
            'brand_id' => 'required|integer|exists:brands,id',
            'type_id' => 'required|integer|exists:machine_types,id',
        ]);
        $model = new \App\Models\Model();
        $model->name = $validated['name'];
        $model->brand_id = $validated['brand_id'];
        $model->type_id = $validated['type_id'];
        $model->save();
        return redirect()->route('models.index')->with('success', 'Model created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $model = \App\Models\Model::findOrFail($id);
        $brands = \App\Models\Brand::all();
        $machineTypes = \App\Models\MachineType::all();
        return view('models.edit', compact('model', 'brands', 'machineTypes'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:models,name,' . $id,
            'brand_id' => 'required|integer|exists:brands,id',
            'type_id' => 'required|integer|exists:machine_types,id',
        ]);
        $model = \App\Models\Model::findOrFail($id);
        $model->name = $validated['name'];
        $model->brand_id = $validated['brand_id'];
        $model->type_id = $validated['type_id'];
        $model->save();
        return redirect()->route('models.index')->with('success', 'Model updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $model = \App\Models\Model::findOrFail($id);
        $model->delete();
        return redirect()->route('models.index')->with('success', 'Model deleted successfully.');
    }
}
