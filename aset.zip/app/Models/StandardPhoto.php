<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StandardPhoto extends Model
{
    protected $fillable = [
        'name',
        'photo_path',
        'description',
    ];

    // Relationships
    public function standards()
    {
        return $this->belongsToMany(Standard::class, 'standard_standard_photo');
    }
}
